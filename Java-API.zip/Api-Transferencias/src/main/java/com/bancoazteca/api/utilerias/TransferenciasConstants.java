package com.bancoazteca.api.utilerias;

/**
 * Constantes 
 * @author B53678
 *
 */
public class TransferenciasConstants {
	
	private TransferenciasConstants() {}
	
	//Transferencias Component
	public static final String FECHA_HABIL_ACTUAL = "1";
	public static final String FECHA_HABIL_FUTURA = "2";

	//Frecuentes DAO
	public static final String ID_FREQ = "_id";
	public static final String HOLOGRAMA = "holograma";
	public static final String AVISO = "aviso";
	public static final String ALIAS = "alias";
	public static final String USUARIO = "usuario";
	public static final String ACTIVA = "activa";
	public static final String DIA_NOT = "diaNot";
	public static final String ID_BANCO = "idBanco";
	public static final String NUM_OPERACIONES = "noOperaciones";
	public static final String DESTINO = "destino";
	public static final String NOMBRE = "nombre";
	public static final String APELLIDO_PATERNO = "apPaterno";
	public static final String APELLIDO_MATERNO = "apMaterno";
	public static final String EMAIL = "email";
	public static final String FECHA_ULT_PAGO = "fUltPago";
	public static final Integer ID_BANCO_AZTECA = 127;
	public static final String FECHA_MOD = "fechaMod";
	public static final String FECHA_NOT = "fechaNot";
	public static final String PERIODO = "periodo";
	public static final Integer ERROR_FRECUENTE_INEXISTENTE = -19;
	public static final String IMPORTE="importe";
	public static final String CONCEPTO = "concepto";
	public static final String REFERENCIA="referencia";
	public static final String APLICACION_DEFECTO="ANDROID";
	
	//Transferencias DAO
	public static final String TIPO_OPERACION_MB42 = "1";
	public static final String OPCION_MB42 = "1";
	public static final String PAGINACION_INICIAL_MB42 = "00001";
	public static final String PAGINACION_FINAL_MB42 = "00000";
	public static final String CODIGO_FIN_LISTA_MB42 = "FEE0013";
    public static final String MENSAJE_FINAL_LISTA_MB42 = "NO HAY DATOS A LISTAR";
    public static final String NUMERODIAS="000";
    public static final String MB08="MB08";
    public static final String F755="F755";
    public static final String MB03="MB03";
    public static final char GUION_MEDIO='-';
    
    //Formatos Fecha
    public static final String FECHA_DDMMYYYY = "dd/MM/yyyy";
    public static final String FECHA_YYYYMMDD = "yyyy-MM-dd";
}
