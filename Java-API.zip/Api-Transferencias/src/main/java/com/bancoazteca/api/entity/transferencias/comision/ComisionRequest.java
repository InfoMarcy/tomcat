package com.bancoazteca.api.entity.transferencias.comision;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Pattern;

import com.bancoazteca.bdm.commons.utils.bean.RequestTO;
import com.bancoazteca.bdm.commons.utils.validation.constraints.telefono.Telefono;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

/**
 * Request para la consulta de comisiones
 * @author B53678
 *
 */
@ApiModel("ComisionRequest")
public class ComisionRequest extends RequestTO
{
	@NotBlank(message="La cuenta cargo es requerida para la operación.")
	@ApiModelProperty(required=true, example="26_it5Shf6cJndIQohn81Q==", notes="Cuenta origen a 14 digitos encriptado con algoritmo alnova")
	private String cuentaOrigen;
	
	@NotBlank(message="La cuenta destino es requerida para la operación.")
	@ApiModelProperty(required=true, example="-ZPtGFzHa7RZUHbr4ME_kw", notes="Cuenta/tarjeta/clabe/celular(id de banco destino a 3 digitos + numero celular a 10 digitos) destino encriptado con algoritmo alnova")
	private String cuentaDestino;
	
	@NotBlank(message="El ID Celular es requerido para la operación.")
	@ApiModelProperty(required=true, example="b4f90714d7ba32e79f9bf2701f1c4fc4", notes="Identificador del celular del cliente")
	private String idCelular;
	
	@NotBlank(message="El Celular es requerido para la operación.")
	@Telefono(message="El Celular no tiene el formato correcto (Solo se aceptan 10 digitos númericos).")
	@ApiModelProperty(value="celular", required=true, example="5564596649")
	private String celular;
	
	@NotBlank(message="La fecha de operación es requerida para la operación.")
	@Pattern(regexp="^([0-2][0-9]|(3)[0-1])(\\/)(((0)[0-9])|((1)[0-2]))(\\/)\\d{4}$", message="Favor verificar el formato de la fecha (dd/mm/yyyy).")
	@ApiModelProperty(value="fechaOperacion", required=true, example="28/02/2019")
	private String fechaOperacion;
	
	@NotBlank(message="El ICU es requerido para la operación.")
	@ApiModelProperty(required=true, example="89fdb313c07d49709b52655b7df12e93", notes="Icu del cliente")
	private String icu;

	public String getCuentaOrigen() {
		return cuentaOrigen;
	}

	public void setCuentaOrigen(String cuentaOrigen) {
		this.cuentaOrigen = cuentaOrigen;
	}

	public String getCuentaDestino() {
		return cuentaDestino;
	}

	public void setCuentaDestino(String cuentaDestino) {
		this.cuentaDestino = cuentaDestino;
	}

	public String getIdCelular() {
		return idCelular;
	}

	public void setIdCelular(String idCelular) {
		this.idCelular = idCelular;
	}

	public String getCelular() {
		return celular;
	}

	public void setCelular(String celular) {
		this.celular = celular;
	}

	public String getFechaOperacion() {
		return fechaOperacion;
	}

	public void setFechaOperacion(String fechaOperacion) {
		this.fechaOperacion = fechaOperacion;
	}

	public String getIcu() {
		return icu;
	}

	public void setIcu(String icu) {
		this.icu = icu;
	}
}
