package com.bancoazteca.api.entity.documents;

import java.util.Date;

import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Field;

import com.bancoazteca.api.utilerias.ClaveDestinoEnum;
import com.bancoazteca.bdm.commons.utils.bean.frecuente.FrecuenteEntity;
import com.fasterxml.jackson.annotation.JsonFormat;

@Document(collection="FreqTrans")
public class FrecuenteTransferenciaEntity extends FrecuenteEntity{
	
	private String destino;
	private String banco;
	private String nombre;
	private String tipo;
	private ClaveDestinoEnum claveDestino;
	private int idBanco;
	private String apPaterno;
	private String apMaterno;
	private String email;
	private String concepto;
	private String referencia;
	@Field("fUltPago")
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "dd/MM/yyyy")
	private Date fechaUltimoPago;
	
	public String getDestino() {
		return destino;
	}
	public void setDestino(String destino) {
		this.destino = destino;
	}
	public String getBanco() {
		return banco;
	}
	public void setBanco(String banco) {
		this.banco = banco;
	}
	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	public String getTipo() {
		return tipo;
	}
	public void setTipo(String tipo) {
		this.tipo = tipo;
	}
	public ClaveDestinoEnum getClaveDestino() {
		return claveDestino;
	}
	public void setClaveDestino(ClaveDestinoEnum claveDestino) {
		this.claveDestino = claveDestino;
	}
	public int getIdBanco() {
		return idBanco;
	}
	public void setIdBanco(int idBanco) {
		this.idBanco = idBanco;
	}
	public String getApPaterno() {
		return apPaterno;
	}
	public void setApPaterno(String apPaterno) {
		this.apPaterno = apPaterno;
	}
	public String getApMaterno() {
		return apMaterno;
	}
	public void setApMaterno(String apMaterno) {
		this.apMaterno = apMaterno;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getConcepto() {
		return concepto;
	}
	public void setConcepto(String concepto) {
		this.concepto = concepto;
	}
	public String getReferencia() {
		return referencia;
	}
	public void setReferencia(String referencia) {
		this.referencia = referencia;
	}
	public Date getFechaUltimoPago() {
		return fechaUltimoPago;
	}
	public void setFechaUltimoPago(Date fechaUltimoPago) {
		this.fechaUltimoPago = fechaUltimoPago;
	}	

}
