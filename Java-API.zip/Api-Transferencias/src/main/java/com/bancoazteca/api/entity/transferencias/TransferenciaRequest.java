package com.bancoazteca.api.entity.transferencias;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;

import com.bancoazteca.bdm.commons.utils.bean.RequestTO;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

/**
 * Request para el servicio de transferencias
 * @author B53678
 *
 */
@ApiModel("TransferenciaRequest")
public class TransferenciaRequest extends RequestTO
{
	
	@Valid
	@NotNull(message="El objeto Origen es requerido para la operación.")
	@ApiModelProperty(required=true, notes="Informacion de la cuenta origen")
	private TransaferenciaOrigenTO origen;

	
	@Valid
	@NotNull(message="El Objeto Destino es requerido para la operación.")
	@ApiModelProperty(value="destino", required=true)
	private TransferenciaDestinoTO destino;

	public TransaferenciaOrigenTO getOrigen() {
		return origen;
	}

	public void setOrigen(TransaferenciaOrigenTO origen) {
		this.origen = origen;
	}


	public TransferenciaDestinoTO getDestino() {
		return destino;
	}

	public void setDestino(TransferenciaDestinoTO destino) {
		this.destino = destino;
	}
}
