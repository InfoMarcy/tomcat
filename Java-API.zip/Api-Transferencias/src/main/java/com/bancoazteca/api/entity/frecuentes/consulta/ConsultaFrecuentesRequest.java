package com.bancoazteca.api.entity.frecuentes.consulta;

import javax.validation.constraints.NotBlank;

import com.bancoazteca.api.utilerias.OpcionConsultarEnum;
import com.bancoazteca.bdm.commons.utils.bean.RequestTO;
import com.bancoazteca.bdm.commons.utils.validation.constraints.enums.EnumType;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

/**
 * Request de la consulta de las cuentas frecuentes del cliente
 * @author B53678
 *
 */
@ApiModel("ConsultarFrecuentesRequest")
public class ConsultaFrecuentesRequest extends RequestTO{
	
	@NotBlank(message="El ICU es requerido para la operación.")
	@ApiModelProperty(required=true, example="589d19b68e8604222b637492", notes="icu, identificador del cliente")
	private String icu;
	
	
	@ApiModelProperty(required=true, example="TODAS", notes="valores permitidos BANCOAZTECA, OTROS, TODAS")
	@NotBlank(message="El filtro es requerido para la operación.")
	@EnumType(message="El filtro no es valido.", enumClass=OpcionConsultarEnum.class)
	private String filtro;

	public String getIcu() {
		return icu;
	}

	public void setIcu(String icu) {
		this.icu = icu;
	}

	public String getFiltro() {
		return filtro;
	}

	public void setFiltro(String filtro) {
		this.filtro = filtro;
	}
}
