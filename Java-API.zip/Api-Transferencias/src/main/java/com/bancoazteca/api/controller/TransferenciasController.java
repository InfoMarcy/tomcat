package com.bancoazteca.api.controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.bancoazteca.api.business.TransferenciaComponent;
import com.bancoazteca.api.entity.transferencias.TransferenciaRequest;
import com.bancoazteca.api.entity.transferencias.TransferenciaResponse;
import com.bancoazteca.api.entity.transferencias.comision.ComisionRequest;
import com.bancoazteca.api.entity.transferencias.comision.ComisionResponse;
import com.bancoazteca.bdm.commons.utils.bean.ResponseError;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@Api("Api Transferencias")
@CrossOrigin
@RestController
@RequestMapping("/transferencias/v1")
@Validated	
public class TransferenciasController {
	
	@Autowired
	private TransferenciaComponent transferenciaComponent;

	@ApiOperation(value="Obtiene la comision de la transferencia", nickname="Obtiene la comision de la transferencia", response=ComisionResponse.class, tags= {"Api Transferencias"})
	@ApiResponses({@ApiResponse(code=200, message="Ok", response=ComisionResponse.class),
				   @ApiResponse(code=400, message="Entrada incorrecta", response=ResponseError.class),
				   @ApiResponse(code=404, message="No encontrado", response=ResponseError.class),
				   @ApiResponse(code=500, message="Error inesperado", response=ResponseError.class)})
	@PostMapping(value="/comisiones", consumes=MediaType.APPLICATION_JSON_VALUE, produces=MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Object> consultaFrecuentes(
			@Valid @RequestHeader(defaultValue="eyJhbGciOiJSUzM4NCIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIxMjM0NTY3ODkwIiwibmFtZSI6IkpvaG4gRG9lIiwiaWF0IjoxNTE2MjM5MDIyLCJIYXNoQ29kZSI6IjY0NTVlMDBjYjgxMWY5MjhhMjgwODNlNzQ1YTcxYjQ5MGYyYzRlYTY4MzE1MGU3MWY4NmQ1NjY4Y2VlODgyOTdkODVmM2ExZTNjZGY2ZTkxZmQ2NGI0YWZkYjEzMDg5M2Q4ZjI3MDY5YmZhNGQ2ZWZlZmM5ZWU1ZTNlZjE1YzBlIn0.bGDQoQTibydo10-EIOnI9cfSJUI2SsA3UUYbnn-0K9qRzL-kstxbe4cqBirh3-Gayjw0rrqkDKkeZi-4MCrGDx4tf2eaABQPsrbD0IixydOKT2DuIHOk383OkigCq9ppr1o9OUrwpsVn_W9QROIQRpQcWqgHsMdzY73j2Qv9oNI", name="Token", required=true) String token,
			@Valid @RequestBody ComisionRequest request)
	{
		return transferenciaComponent.consultaComision(request);
	}
	
	@ApiOperation(value="Realiza la transferencia", nickname="Realiza la transferencia", response=TransferenciaResponse.class, tags= {"Api Transferencias"})
	@ApiResponses({@ApiResponse(code=201, message="Creado", response=TransferenciaResponse.class),
				   @ApiResponse(code=400, message="Entrada incorrecta", response=ResponseError.class),
				   @ApiResponse(code=404, message="No encontrado", response=ResponseError.class),
				   @ApiResponse(code=500, message="Error inesperado", response=ResponseError.class)})
	@PostMapping(consumes=MediaType.APPLICATION_JSON_VALUE, produces=MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Object> ejecutaEnvio(
			@Valid @RequestHeader(defaultValue="eyJhbGciOiJSUzM4NCIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIxMjM0NTY3ODkwIiwibmFtZSI6IkpvaG4gRG9lIiwiaWF0IjoxNTE2MjM5MDIyLCJIYXNoQ29kZSI6IjY0NTVlMDBjYjgxMWY5MjhhMjgwODNlNzQ1YTcxYjQ5MGYyYzRlYTY4MzE1MGU3MWY4NmQ1NjY4Y2VlODgyOTdkODVmM2ExZTNjZGY2ZTkxZmQ2NGI0YWZkYjEzMDg5M2Q4ZjI3MDY5YmZhNGQ2ZWZlZmM5ZWU1ZTNlZjE1YzBlIn0.bGDQoQTibydo10-EIOnI9cfSJUI2SsA3UUYbnn-0K9qRzL-kstxbe4cqBirh3-Gayjw0rrqkDKkeZi-4MCrGDx4tf2eaABQPsrbD0IixydOKT2DuIHOk383OkigCq9ppr1o9OUrwpsVn_W9QROIQRpQcWqgHsMdzY73j2Qv9oNI", name="Token", required=true) String token,
			@Valid @RequestBody TransferenciaRequest request)
	
	{
		return transferenciaComponent.ejecutaEnvio(request);
	}

}
