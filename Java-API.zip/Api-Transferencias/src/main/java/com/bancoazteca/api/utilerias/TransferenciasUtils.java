package com.bancoazteca.api.utilerias;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.bancoazteca.bdm.commons.utils.Validations;

/**
 * Utileria para Transferencias
 * @author B53678
 *
 */
public class TransferenciasUtils {
	
	private static final Logger LOG = LoggerFactory.getLogger(TransferenciasUtils.class);
	
	private TransferenciasUtils() {}

	/**
	 * Metodo apra convertir una fecha con formato String en un Date
	 * @param fechaString Fecha en formato String
	 * @param formatoEntrada Formato de la fecha de entrada ex. dd/MM/yyyy
	 * @return Date
	 */
	public static Date formateaFechaStringtoDate(String fechaString, String formatoEntrada) {
		Date fechaModificacion = new Date();
		SimpleDateFormat formatter = new SimpleDateFormat(formatoEntrada);
        try {
        	fechaModificacion = formatter.parse(fechaString);
        	return fechaModificacion;
        } catch (ParseException e) {
        	LOG.error("Exception ... {}", e);
        }
		return fechaModificacion;
	}
	
	/**
	 * Metodo para dar formato a una Fecha Date en un tipo String
	 * @param fecha Date con la fecha de entrada
	 * @param formatoSalida formato de salida de la fecha String ex. yyyy-MM-dd
	 * @return String
	 */
	public static String formateaFechaDatetoString(Date fecha, String formatoSalida) {
		SimpleDateFormat simpleDateFormat = new SimpleDateFormat(formatoSalida);
		return simpleDateFormat.format(fecha);
	}
	
	/**
	 * Metodo para obtener el numero de dia a partir de una determinada fecha
	 * @param fecha fecha de tipo Date
	 * @return int 
	 */
	public static int getDia(Date fecha) {
		Calendar cal = Calendar.getInstance();
		cal.setTime(fecha);
		return cal.get(Calendar.DAY_OF_MONTH);
	}
	
	/**
	 * Metodo que valida y da formato al RFC de entrada
	 * @param constantesRFC
	 * @return String
	 */
	public static String stringRfc(String constantesRFC) {
        String rfc;
        if(Validations.isNullOrEmpty(constantesRFC) || constantesRFC.length()<13){
            rfc = String.format("%1$-13s", constantesRFC);
        } else{
            rfc = constantesRFC;
        }
        return rfc;
    }
}
