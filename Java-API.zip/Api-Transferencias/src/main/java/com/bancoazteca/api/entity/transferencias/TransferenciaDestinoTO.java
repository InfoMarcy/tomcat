package com.bancoazteca.api.entity.transferencias;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Pattern;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

@ApiModel("TransferenciaDestinoTO")
public class TransferenciaDestinoTO
{

	@NotBlank(message="El número de tarjeta/cuenta/clabe es requerida para la operación.")
	@ApiModelProperty(required = true, example = "u5_bBpxYLD4xgntYGtpdzg==", notes="Numero de tarjeta/cuenta/clabe/celular(id de banco destino a 3 digitos + numero celular a 10 digitos) encriptado con algoritmo alnova.")
	private String tarjeta;

	@NotBlank(message="El monto es requerido para la operación.")
	@ApiModelProperty(required = true, example = "4tKZ6g0ZYvtnIo7ykDUA3Q", notes="Monto de la transferencia, con formato y encriptado alnova")
	private String monto;

	@NotBlank(message="La referencia es requerida para la operación.")
	@ApiModelProperty(required = true, example = "1234567", notes="Referencia de la transferencia")
	private String referencia;

	@NotBlank(message="El concepto es requerido para la operación.")
	@ApiModelProperty(required = true, example = "PARA EL PAGO DE RENTA", notes="Concepto de la transferencia")
	private String concepto;

	@NotBlank(message="La fecha de operación es requerida para la operación.")
	@ApiModelProperty(value = "fechaOperacion", required = true, example = "25/01/2019")
	@Pattern(regexp="^([0-2][0-9]|(3)[0-1])(\\/)(((0)[0-9])|((1)[0-2]))(\\/)\\d{4}$", message="Favor verificar el formato de la fecha (dd/mm/yyyy).")
	private String fechaOperacion;

	@ApiModelProperty(required = false, example = "Transferencia para el pago de la renta", notes="Descripcion de la transferencia")
	private String descripcion;

	public String getTarjeta() {
		return tarjeta;
	}

	public void setTarjeta(String tarjeta) {
		this.tarjeta = tarjeta;
	}

	public String getMonto() {
		return monto;
	}

	public void setMonto(String monto) {
		this.monto = monto;
	}

	public String getReferencia() {
		return referencia;
	}

	public void setReferencia(String referencia) {
		this.referencia = referencia;
	}

	public String getConcepto() {
		return concepto;
	}

	public void setConcepto(String concepto) {
		this.concepto = concepto;
	}

	public String getFechaOperacion() {
		return fechaOperacion;
	}

	public void setFechaOperacion(String fechaOperacion) {
		this.fechaOperacion = fechaOperacion;
	}

	public String getDescripcion() {
		return descripcion;
	}

	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}
}
