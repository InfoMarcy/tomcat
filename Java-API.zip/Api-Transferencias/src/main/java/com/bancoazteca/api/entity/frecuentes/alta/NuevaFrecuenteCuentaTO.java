package com.bancoazteca.api.entity.frecuentes.alta;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

import com.bancoazteca.api.utilerias.ClaveDestinoEnum;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

@ApiModel("NuevoFrecuenteCuentaTO")
public class NuevaFrecuenteCuentaTO
{
	

   
	@NotBlank(message="El alias es requerida para la operación.")
	@Pattern(regexp="([a-zA-Z0-9 ]){0,30}+$", message="El alias debe tener máximo 30 caracteres. No se aceptan caracteres especiales.")
	@ApiModelProperty(example="Cuenta de Renta", notes="Alias que se le asignara a la frecuente", required=true)
	private String alias;
	
	

   
	@NotBlank(message="El número de tarjeta/clabe/cuenta o teléfono es requerido para la operación.")
	@ApiModelProperty(example="-OoCjzq3qxeh_x1e4elChR0OUlaPXYtdJVsVtnXhniI", notes="Numero de cta/clabe/tarjeta/celular(id de banco destino a 3 digitos + numero celular a 10 digitos) de la frecuente, con encriptado alnova", required=true)
	private String numeroTarjeta;
	

    
   
	@NotNull(message="La Clave Destino es requerida para la operación.")
	@ApiModelProperty(example="TARJETA", notes="valor validos = CLABE, TARJETA, CUENTA, TELEFONO")
	private ClaveDestinoEnum claveDestino;

	public String getAlias() {
		return alias;
	}

	public void setAlias(String alias) {
		this.alias = alias;
	}

	public String getNumeroTarjeta() {
		return numeroTarjeta;
	}

	public void setNumeroTarjeta(String numeroTarjeta) {
		this.numeroTarjeta = numeroTarjeta;
	}

	public ClaveDestinoEnum getClaveDestino() {
		return claveDestino;
	}

	public void setClaveDestino(ClaveDestinoEnum claveDestino) {
		this.claveDestino = claveDestino;
	}


}
