 package com.bancoazteca.api.business;

import java.io.UnsupportedEncodingException;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.regex.Pattern;
import java.util.regex.PatternSyntaxException;

import javax.crypto.BadPaddingException;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.xml.bind.JAXBException;

import org.apache.commons.lang.WordUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.bancoazteca.api.dao.FrecuentesDAO;
import com.bancoazteca.api.dao.TransferenciaDAO;
import com.bancoazteca.api.entity.documents.FrecuenteTransferenciaEntity;
import com.bancoazteca.api.entity.frecuentes.alta.AltaFrecuenteRequest;
import com.bancoazteca.api.entity.frecuentes.consulta.ConsultaFrecuenteTO;
import com.bancoazteca.api.entity.frecuentes.consulta.ConsultaFrecuenteTitularTO;
import com.bancoazteca.api.entity.frecuentes.consulta.ConsultaFrecuenteUltimoEnvioTO;
import com.bancoazteca.api.entity.frecuentes.consulta.ConsultaFrecuentesRequest;
import com.bancoazteca.api.entity.frecuentes.consulta.ConsultaFrecuentesResponse;
import com.bancoazteca.api.entity.frecuentes.consulta.ConsultaFrecuentesResultadoTO;
import com.bancoazteca.api.entity.frecuentes.editar.EditarFrecuenteRequest;
import com.bancoazteca.api.entity.transferencias.comision.CuentaTO;
import com.bancoazteca.api.entity.transferencias.comision.InformacionTarjetaBean;
import com.bancoazteca.api.utilerias.ClaveDestinoEnum;
import com.bancoazteca.api.utilerias.OpcionConsultarEnum;
import com.bancoazteca.api.utilerias.TransferenciasConstants;
import com.bancoazteca.bdm.commons.utils.Validations;
import com.bancoazteca.bdm.commons.utils.annotation.Servicio;
import com.bancoazteca.bdm.commons.utils.bean.ResponseTO;
import com.bancoazteca.bdm.commons.utils.exception.MessageException;
import com.bancoazteca.lib.business.HologramaComponent;
import com.bancoazteca.lib.transacciones.MB06Request;
import com.bancoazteca.ms.alnova.entity.beans.transaccion.mb03.MB03Response;
import com.bancoazteca.ms.alnova.entity.beans.transaccion.mb08.MB08Response;
import com.bancoazteca.ms.firmaDigital.FirmaDigitalComponent;
import com.bancoazteca.ms.firmaDigital.exceptions.FirmaDigitalException;

/**º
 * @author Cesar M Orozco R
 *
 */
@Service
public class FrecuentesComponent {
	
	@Autowired
	FirmaDigitalComponent firmaDigital;
	
	private static final Logger LOG = LoggerFactory.getLogger(FrecuentesComponent.class);
	
	@Autowired
	FrecuentesDAO frecuentesDAO;
	@Autowired
	TransferenciaDAO transferenciaDao;
	@Autowired
	HologramaComponent hologramaComponent;
	
	/**
	 * Metodo que guarda la frecuente
	 * @param request
	 */
	@Servicio(codeCircuitBreaker=1105, projectName="Transferencias")
	public ResponseEntity<Object> guardaFrecuente(AltaFrecuenteRequest request) {
		
		LOG.info("FrecuenteComponent :::: Guarda Frecuente...");
		ResponseTO responseTO = new ResponseTO();
		FrecuenteTransferenciaEntity entityBD = frecuentesDAO.recuperaFrecuente(request.getDetalle().getCuenta().getNumeroTarjeta(), request.getIcu());
		FrecuenteTransferenciaEntity entity = creaEntityFrecuente(request, obtieneInfoTarjeta(request));
		if(Validations.isNullOrEmpty(entityBD)) {
			LOG.info("Se guarda frecuente nueva...");
			guardaFrecuenteConHolograma(entity);
		} else {
			if (!entityBD.getActiva()) {
				LOG.info("Se reactiva la frecuente...");
				entityBD.setNombre(entity.getNombre());
				entityBD.setAlias(entity.getAlias());
				entityBD.setApPaterno(entity.getApPaterno());
				entityBD.setApMaterno(entity.getApMaterno());
				altaYActivacionHolograma(entityBD);
				frecuentesDAO.reactivarFrecuente(entityBD);
			} else if(!entityBD.getHolograma().booleanValue()) {
				LOG.info("Se cambiara el estatus del holograma");
				activarHolograma(entityBD);
				frecuentesDAO.cambiarEstatusHolograma(entityBD.getId());
			} else if(entityBD.getHolograma().booleanValue() && entityBD.getActiva())
						throw new MessageException(1108, HttpStatus.BAD_REQUEST);
		}
		return new ResponseEntity<>(responseTO, HttpStatus.CREATED);
	}
	
	/**
	 * Metodo que realiza la consulta de frecuentes, catalogo de bancos y consulta de valor unidad
	 * @param request
	 * @return
	 */
	@Servicio(codeCircuitBreaker=1105, projectName="Transferencias")
	public ResponseEntity<Object> consultaFrecuentes(ConsultaFrecuentesRequest request) {
		LOG.info("FrecuentesComponent::: consultaFrecuentes");
		ConsultaFrecuentesResponse consultaFrecuentesResponse = new ConsultaFrecuentesResponse();
		ConsultaFrecuentesResultadoTO resultado=new ConsultaFrecuentesResultadoTO();
		
		List<FrecuenteTransferenciaEntity> frecuentes = frecuentesDAO.consultaFrecuentes(request.getIcu(), OpcionConsultarEnum.valueOf(request.getFiltro()));
		activarHolograma(frecuentes, request.getIcu());
		resultado.setFrecuentes(crearFrecuentes(frecuentes));
		consultaFrecuentesResponse.setResultado(resultado);
//		consultaFrecuentesResponse.setFrecuentes(frecuentes);
//		consultaFrecuentesResponse.setCatalogoBancos(transferenciaDao.ejecutaTXMB42CatalogoBancos());	
		
		
		
		
		if(frecuentes.isEmpty()) {
			throw new MessageException(1109, HttpStatus.NOT_FOUND);
			
		}
		
		return new ResponseEntity<>(consultaFrecuentesResponse, HttpStatus.OK);
	}
	
	/**
	 * Metodo que editar la frecuente seleccionada por el usuario
	 * @param request
	 * @return
	 * @throws JAXBException 
	 * @throws UnsupportedEncodingException 
	 * @throws InvalidAlgorithmParameterException 
	 * @throws BadPaddingException 
	 * @throws IllegalBlockSizeException 
	 * @throws NoSuchPaddingException 
	 * @throws NoSuchAlgorithmException 
	 * @throws InvalidKeyException 
	 */
	@Servicio(codeCircuitBreaker=1105, projectName="Transferencias")
	public ResponseEntity<Object> editaFrecuente(EditarFrecuenteRequest request) throws JAXBException
	{

					
				try {
					firmaDigital.verificarFirmaDigital(request.getIcu().toString(), request.getFirmaDigital().toString());
				} catch (FirmaDigitalException e) {
					
					throw new MessageException(1150, HttpStatus.BAD_REQUEST);
				}
				
		
		
		if(isNullOrEmpty(request.getDetalle().getAlias()) && isNullOrEmpty(request.getDetalle().getCorreoElectronico())) {
			throw new MessageException(1112, HttpStatus.BAD_REQUEST);
		}
		
		
		
		ResponseTO response = new ResponseTO();
		FrecuenteTransferenciaEntity entity = new FrecuenteTransferenciaEntity();
		entity.setUsuario(request.getIcu());
		entity.setId(request.getDetalle().getIdFrecuente());
		entity.setAlias(request.getDetalle().getAlias() != null ? request.getDetalle().getAlias().toUpperCase() : request.getDetalle().getAlias());
		entity.setEmail(request.getDetalle().getCorreoElectronico());
		frecuentesDAO.editaFrecuente(entity);
		
		return new ResponseEntity<>(response, HttpStatus.OK);
	}
	
	/**
	 * Metodo que elimina la frecuente seleccionada por el usuario
	 * @param request
	 * @return
	 */
	@Servicio(codeCircuitBreaker=1105, projectName="Transferencias")
	public ResponseEntity<Object> eliminaFrecuente(String idFrecuente, String icu) { 
		
		
		ResponseTO responseTO = new ResponseTO();
		
		// find client by iCU
		Query findIcu = new Query(Criteria.where(TransferenciasConstants.USUARIO).is(icu));
		FrecuenteTransferenciaEntity entityICU = frecuentesDAO.recuperaICU(icu);
		

		if(Validations.isNullOrEmpty(entityICU))
			throw new MessageException(1144, HttpStatus.NOT_FOUND);
		
		
		FrecuenteTransferenciaEntity entity = frecuentesDAO.recuperaFrecuente(idFrecuente);
		if(Validations.isNullOrEmpty(entity) || !entity.getActiva())
			throw new MessageException(1104, HttpStatus.NOT_FOUND);
		
		frecuentesDAO.eliminaFrecuente(idFrecuente, icu);		
		MB06Request mb06Request = new MB06Request();
		mb06Request.setIcuCliente(entity.getUsuario());
		mb06Request.setCuentaDestino(entity.getDestino());
		mb06Request.setClaveDestino(entity.getClaveDestino().getClave());
		hologramaComponent.bajaHolograma(mb06Request, TransferenciasConstants.APLICACION_DEFECTO);
		return new ResponseEntity<>(responseTO, HttpStatus.OK);
	}
	
	
	public void incrementaContador(String usuario, String concepto, MB03Response mb03Response) {
		frecuentesDAO.incrementarContador(usuario, mb03Response.getCuentaDestino(), mb03Response.getMonto(), concepto, mb03Response.getNumReferencia());
	}
	
	private void activarHolograma(List<FrecuenteTransferenciaEntity> frecuentes, String icuCliente) {
		frecuentes.stream().forEach(f -> {
			if(f.getHolograma() != null && !f.getHolograma()) {
				MB06Request mb06Request = new MB06Request();
				mb06Request.setIcuCliente(icuCliente);
				mb06Request.setFirmaDigital(f.getFirmaDigital());
				mb06Request.setCuentaDestino(f.getDestino());
				mb06Request.setClaveDestino(f.getClaveDestino().getClave());
				hologramaComponent.activaHolograma(mb06Request, TransferenciasConstants.APLICACION_DEFECTO);
				frecuentesDAO.cambiarEstatusHolograma(f.getId());
				f.setFirmaDigital(null);
			}
		});
	}
	
	@SuppressWarnings("unused")
	private void activarHolograma(FrecuenteTransferenciaEntity entityTO) {
		if(entityTO.getHolograma() != null && !entityTO.getHolograma()) {
			MB06Request mb06RequestTO = creaPojoMb06Request(entityTO);
			hologramaComponent.activaHolograma(datosBeneficiarioNull(mb06RequestTO), TransferenciasConstants.APLICACION_DEFECTO);
		}
	}
	
	@SuppressWarnings("unused")
	private void altaYActivacionHolograma(FrecuenteTransferenciaEntity entity) {
		MB06Request mb06RequestTO = creaPojoMb06Request(entity);
		hologramaComponent.altaHolograma(mb06RequestTO, TransferenciasConstants.APLICACION_DEFECTO);
		hologramaComponent.activaHolograma(datosBeneficiarioNull(mb06RequestTO), TransferenciasConstants.APLICACION_DEFECTO);
	}
	
	private void guardaFrecuenteConHolograma(FrecuenteTransferenciaEntity entity) {
		MB06Request mb06Request = creaPojoMb06Request(entity);
		hologramaComponent.altaHolograma(mb06Request, TransferenciasConstants.APLICACION_DEFECTO);
		hologramaComponent.activaHolograma(datosBeneficiarioNull(mb06Request), TransferenciasConstants.APLICACION_DEFECTO);
		entity.setFechaModificacion(new Date());
		entity.setFechaRegistro(new Date());
		entity.setActiva(true);
		entity.setNumeroOperaciones(0);
		entity.setHolograma(true);
		frecuentesDAO.guardaFrecuente(entity);
	}
	
	private MB06Request creaPojoMb06Request(FrecuenteTransferenciaEntity entity) {
		MB06Request mb06Request = new MB06Request();
		ClaveDestinoEnum claveDestino = entity.getClaveDestino();
		mb06Request.setIcuCliente(entity.getUsuario());
		mb06Request.setCuentaDestino(entity.getDestino());
		mb06Request.setClaveDestino(claveDestino.getClave());
		mb06Request.setFirmaDigital(entity.getFirmaDigital());
		mb06Request.setNombreBeneficiario(entity.getNombre());
		mb06Request.setApPaterno(entity.getApPaterno());
		mb06Request.setApMaterno(entity.getApMaterno());
		return mb06Request;
	}
	
	private MB06Request datosBeneficiarioNull(MB06Request mb06Request) {
		mb06Request.setNombreBeneficiario(null);
		mb06Request.setApPaterno(null);
		mb06Request.setApMaterno(null);
		return mb06Request;
	}
	
	private FrecuenteTransferenciaEntity creaEntityFrecuente(AltaFrecuenteRequest request, InformacionTarjetaBean informacionTarjetaBean) {
		LOG.info("Se crea el entity de la frecuente...");
		FrecuenteTransferenciaEntity entity = new FrecuenteTransferenciaEntity();
		
		entity.setUsuario(request.getIcu());
		entity.setAlias(request.getDetalle().getCuenta().getAlias());		
		entity.setDestino(informacionTarjetaBean.getCuenta().getTarjeta());
		entity.setNombre(!Validations.isNullOrEmpty(informacionTarjetaBean.getNombre()) ? informacionTarjetaBean.getNombre() : request.getDetalle().getTitular().getNombre());
		entity.setApPaterno(!Validations.isNullOrEmpty(informacionTarjetaBean.getApellidoPaterno()) ? informacionTarjetaBean.getApellidoPaterno() : request.getDetalle().getTitular().getApellidoPaterno());
		entity.setApMaterno(!Validations.isNullOrEmpty(informacionTarjetaBean.getApellidoMaterno()) ? informacionTarjetaBean.getApellidoMaterno() : request.getDetalle().getTitular().getApellidoMaterno());		
		entity.setIdBanco(informacionTarjetaBean.getCuenta().getIdBanco());
		entity.setBanco(informacionTarjetaBean.getCuenta().getBanco());
		entity.setTipo(informacionTarjetaBean.getCuenta().getTipo());
//		entity.setClaveDestino(ClaveDestinoEnum.valueOf(request.getDetalle().getCuenta().getClaveDestino()));
		entity.setClaveDestino(request.getDetalle().getCuenta().getClaveDestino());
		
		return entity;
	}
	
	private InformacionTarjetaBean obtieneInfoTarjeta(AltaFrecuenteRequest request) {
		LOG.info("Obteniendo informaci�n de la tarjeta....");
		InformacionTarjetaBean infoTarjeta = new InformacionTarjetaBean();
		CuentaTO cuenta=new CuentaTO();
		
		MB08Response mb08Response = transferenciaDao.ejecutaTXMB08InfoTarjeta(request.getIcu(), request.getDetalle().getCuenta().getNumeroTarjeta());
		cuenta.setTarjeta(request.getDetalle().getCuenta().getNumeroTarjeta());
        cuenta.setBanco(WordUtils.capitalize(mb08Response.getBanco() != null ? mb08Response.getBanco().toLowerCase().trim() : ""));
        cuenta.setTipo(mb08Response.getTipoCuenta());
        cuenta.setTipoTarjeta(mb08Response.getTipoTarjeta());
        if(Validations.isNumerico(mb08Response.getIdBanco()))
        	cuenta.setIdBanco(Integer.parseInt(mb08Response.getIdBanco()));
        
        infoTarjeta.setNombre(mb08Response.getNombre());
        infoTarjeta.setApellidoPaterno(mb08Response.getApellidoP());
        infoTarjeta.setApellidoMaterno(mb08Response.getApellidoM());
        infoTarjeta.setCuenta(cuenta);
        
        return infoTarjeta;
	}
	
	private List<ConsultaFrecuenteTO> crearFrecuentes(List<FrecuenteTransferenciaEntity> frecuentes)
	{
		SimpleDateFormat formatoFecha=new SimpleDateFormat(TransferenciasConstants.FECHA_DDMMYYYY);
		List<ConsultaFrecuenteTO> lstFrecuentes=new ArrayList<>();
		
		for(FrecuenteTransferenciaEntity frecuente:frecuentes) {
			ConsultaFrecuenteTO frecuenteTO=new ConsultaFrecuenteTO();
			ConsultaFrecuenteTitularTO frecuenteTitular=new ConsultaFrecuenteTitularTO();
			ConsultaFrecuenteUltimoEnvioTO frecuenteUltimoEnvio=new ConsultaFrecuenteUltimoEnvioTO();
			
			frecuenteTO.setAlias(frecuente.getAlias());
			frecuenteTO.setBanco(frecuente.getBanco());
			frecuenteTO.setCuenta(frecuente.getDestino());
			frecuenteTO.setFechaModificacion(formatoFecha.format(frecuente.getFechaModificacion()));
			frecuenteTO.setFechaRegistro(formatoFecha.format(frecuente.getFechaRegistro()));
			frecuenteTO.setFirmaDigital(frecuente.getFirmaDigital());
			frecuenteTO.setHolograma(frecuente.getHolograma());
			frecuenteTO.setId(frecuente.getId());
			frecuenteTO.setIdBanco(String.valueOf(frecuente.getIdBanco()));
			frecuenteTO.setTransferenciasRealizadas(frecuente.getNumeroOperaciones());
			frecuenteTO.setTipo(frecuente.getTipo());
			
			frecuenteTitular.setNombre(frecuente.getNombre());
			frecuenteTitular.setApellidoPaterno(frecuente.getApPaterno());
			frecuenteTitular.setApellidoMaterno(frecuente.getApMaterno());
			frecuenteTitular.setCorreoElectronico(frecuente.getEmail());
			frecuenteTO.setTitular(frecuenteTitular);
			
			frecuenteUltimoEnvio.setConcepto(frecuente.getConcepto());
			frecuenteUltimoEnvio.setFecha(Validations.isNullOrEmpty(frecuente.getFechaUltimoPago()) ? "":formatoFecha.format(frecuente.getFechaUltimoPago()));
			frecuenteUltimoEnvio.setImporte(frecuente.getImporte());
			frecuenteUltimoEnvio.setReferencia(frecuente.getReferencia());
			frecuenteTO.setUltimaOperacion(frecuenteUltimoEnvio);
			
			lstFrecuentes.add(frecuenteTO);
		}
		
		return lstFrecuentes;
	}
	
	public  boolean validateEmail(Object correoElectronico)
	{
		boolean flag = false;
		
		if (!isNullOrEmpty(correoElectronico))
		{
			try 
			{
				flag = Pattern.matches("^[a-zA-Z0-9\\._](-|[a-zA-Z0-9\\._])*[a-zA-Z0-9\\._]@[a-zA-Z0-9](-|[a-zA-Z0-9\\._])*[a-zA-Z0-9][\\._][a-zA-Z](-|[a-zA-Z0-9\\._])*[a-zA-Z0-9]$", correoElectronico.toString().trim());
			} catch (PatternSyntaxException e) {
				return false;
			}
		}
		return flag;
	}
	
	public  boolean isNullOrEmpty(Object data) {
		boolean flag = false;
		if (isNull(data)) {
			flag = true;
		} else {
			if (String.valueOf(data).trim().isEmpty()) {
				flag = true;
			}
		}
		return flag;
	}
	
	public  boolean isNull(Object data) {
		boolean flag = false;
		if (data == null) {
			flag = true;
		}
		return flag;
	}
	


	
	
}
