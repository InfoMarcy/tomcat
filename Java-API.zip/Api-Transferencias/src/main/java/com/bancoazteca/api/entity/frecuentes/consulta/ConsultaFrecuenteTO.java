package com.bancoazteca.api.entity.frecuentes.consulta;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

@ApiModel("ConsultaFrecuenteTO")
public class ConsultaFrecuenteTO
{
	@ApiModelProperty(example="5c4f5195718ab9617bb5100a", notes="Identificador de la frecuente")
	private String id;
	
	@ApiModelProperty(example="CUENTA PARA RENTA", notes="Alias de la frecuente")
	private String alias;
	
	@ApiModelProperty(example="12/12/2018", notes="Fecha en que se registro la frecuente")
	private String fechaRegistro;
	
	@ApiModelProperty(example="qo4DvBNZ3nNJkNUvHD34BDs8HyUdhRroH7h1KGhYzEg", notes="Cta/Clabe/tarjeta/Telefono de la frecuente")
	private String cuenta;
	
	@ApiModelProperty(example="DEBITO", notes="Tipo de destino")
	private String tipo;
	
	@ApiModelProperty(example="127", notes="id del banco al que pertenece la cta/tarjeta... de la frecuente")
	private String idBanco;
	
	@ApiModelProperty(notes="Nombre del banco de la frecuente", example="Banco Azteca")
	private String banco;
	
	@ApiModelProperty(notes="contador de transferencias realizadas", example="10")
	private int transferenciasRealizadas;
	
	@ApiModelProperty(notes="Fecha de ultima modificacion de la frecuente formato dd/MM/yyyy", example="25/01/2019")
	private String fechaModificacion;
	
	@ApiModelProperty(notes="FirmaDigital del alta de la frecuente", example="e7xtEkO4wFM54xm-ccgbfw")
	private String firmaDigital;
	
	@ApiModelProperty(notes="Indica si la frecuente tiene activo holograma", example="false")
	private boolean holograma;
	
	@ApiModelProperty(notes="Informacion de titular frecuente")
	private ConsultaFrecuenteTitularTO titular;
	
	@ApiModelProperty(value="ultimaOperacion")
	private ConsultaFrecuenteUltimoEnvioTO ultimaOperacion;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getAlias() {
		return alias;
	}

	public void setAlias(String alias) {
		this.alias = alias;
	}

	public String getFechaRegistro() {
		return fechaRegistro;
	}

	public void setFechaRegistro(String fechaRegistro) {
		this.fechaRegistro = fechaRegistro;
	}

	public String getCuenta() {
		return cuenta;
	}

	public void setCuenta(String cuenta) {
		this.cuenta = cuenta;
	}

	public String getTipo() {
		return tipo;
	}

	public void setTipo(String tipo) {
		this.tipo = tipo;
	}

	public String getIdBanco() {
		return idBanco;
	}

	public void setIdBanco(String idBanco) {
		this.idBanco = idBanco;
	}

	public String getBanco() {
		return banco;
	}

	public void setBanco(String banco) {
		this.banco = banco;
	}

	public int getTransferenciasRealizadas() {
		return transferenciasRealizadas;
	}

	public void setTransferenciasRealizadas(int transferenciasRealizadas) {
		this.transferenciasRealizadas = transferenciasRealizadas;
	}

	public String getFechaModificacion() {
		return fechaModificacion;
	}

	public void setFechaModificacion(String fechaModificacion) {
		this.fechaModificacion = fechaModificacion;
	}

	public String getFirmaDigital() {
		return firmaDigital;
	}

	public void setFirmaDigital(String firmaDigital) {
		this.firmaDigital = firmaDigital;
	}

	public boolean isHolograma() {
		return holograma;
	}

	public void setHolograma(boolean holograma) {
		this.holograma = holograma;
	}

	public ConsultaFrecuenteTitularTO getTitular() {
		return titular;
	}

	public void setTitular(ConsultaFrecuenteTitularTO titular) {
		this.titular = titular;
	}

	public ConsultaFrecuenteUltimoEnvioTO getUltimaOperacion() {
		return ultimaOperacion;
	}

	public void setUltimaOperacion(ConsultaFrecuenteUltimoEnvioTO ultimaOperacion) {
		this.ultimaOperacion = ultimaOperacion;
	}
}
