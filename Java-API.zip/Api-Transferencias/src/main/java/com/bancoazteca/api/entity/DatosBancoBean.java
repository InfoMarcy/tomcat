package com.bancoazteca.api.entity;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

/**
 * Bean con la informaci�n del banco
 * @author B53678
 *
 */
@ApiModel("DatosBancoBean")
public class DatosBancoBean {
	
	@ApiModelProperty(value="codigoBanco", example="040062")
	private String codigoBanco;

	@ApiModelProperty(value="nombreCorto", example="AFIRME")
	private String nombreCorto;
	
	@ApiModelProperty(value="nombreLargo", example="AFIRME")
	private String nombreLargo;
	
	public String getCodigoBanco() {
		return codigoBanco;
	}
	public void setCodigoBanco(String codigoBanco) {
		this.codigoBanco = codigoBanco;
	}
	public String getNombreCorto() {
		return nombreCorto;
	}
	public void setNombreCorto(String nombreCorto) {
		this.nombreCorto = nombreCorto;
	}
	public String getNombreLargo() {
		return nombreLargo;
	}
	public void setNombreLargo(String nombreLargo) {
		this.nombreLargo = nombreLargo;
	}

}
