package com.bancoazteca.api.business;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.regex.Pattern;
import java.util.regex.PatternSyntaxException;

import org.apache.commons.lang.WordUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.bancoazteca.api.dao.TransferenciaDAO;
import com.bancoazteca.api.entity.transferencias.TransferenciaRequest;
import com.bancoazteca.api.entity.transferencias.TransferenciaResponse;
import com.bancoazteca.api.entity.transferencias.TransferenciaRespuestaTO;
import com.bancoazteca.api.entity.transferencias.comision.ComisionRequest;
import com.bancoazteca.api.entity.transferencias.comision.ComisionResponse;
import com.bancoazteca.api.entity.transferencias.comision.ComisionTO;
import com.bancoazteca.api.entity.transferencias.comision.CuentaTO;
import com.bancoazteca.api.entity.transferencias.comision.InformacionTarjetaBean;
import com.bancoazteca.api.utilerias.TransferenciasConstants;
import com.bancoazteca.api.utilerias.TransferenciasUtils;
import com.bancoazteca.bdm.commons.utils.Validations;
import com.bancoazteca.bdm.commons.utils.annotation.Servicio;
import com.bancoazteca.bdm.commons.utils.exception.MessageException;
import com.bancoazteca.ms.alnova.entity.beans.transaccion.f755.F755Response;
import com.bancoazteca.ms.alnova.entity.beans.transaccion.mb03.MB03Request;
import com.bancoazteca.ms.alnova.entity.beans.transaccion.mb03.MB03Response;
import com.bancoazteca.ms.alnova.entity.beans.transaccion.mb08.MB08Response;

@Service
public class TransferenciaComponent {
	

	
	private static final Logger LOG = LoggerFactory.getLogger(TransferenciaComponent.class);
	
	@Autowired
	private TransferenciaDAO transferenciaDAO;
	@Autowired
	private FrecuentesComponent frecuentesComponent;
			
	/**
	 * Metodo que consulta la comision, el monto limitado y la informacion de la tarjeta destino
	 * @param request
	 * @return ResponseEntity
	 */
	@Servicio(codeCircuitBreaker=1105, projectName="Transferencias")
	public ResponseEntity<Object> consultaComision(ComisionRequest request)
	{
		LOG.info("Entra al metodo de consultar comision :::: TransferenciaComponent");
		ComisionResponse comisionResponse = new ComisionResponse();
		ComisionTO comisionTO=new ComisionTO();
		
		if(request.getCuentaOrigen().equalsIgnoreCase(request.getCuentaDestino()))
			throw new MessageException(1100, HttpStatus.BAD_REQUEST);
		comisionTO.setDestinatario(obtieneInfoTarjeta(request.getIcu(), request.getCuentaDestino()));
		comisionTO.setComision(transferenciaDAO.ejecutaTXMB18Comision(request).getComision());
		comisionTO.setMontoLimitado(montoLimitado(request));
		comisionResponse.setResultado(comisionTO);
		
		return new ResponseEntity<>(comisionResponse, HttpStatus.OK);
	}
	
	/**
	 * Metodo que realiza la ejecucion del envio de dinero
	 * @param request
	 * @return ResponseEntity
	 */
	@Servicio(codeCircuitBreaker=1105, projectName="Transferencias")
	public ResponseEntity<Object> ejecutaEnvio(TransferenciaRequest request)
	{
			
		TransferenciaResponse response = new TransferenciaResponse();
		TransferenciaRespuestaTO respuestaTO=new TransferenciaRespuestaTO();
		
		if(request.getOrigen().getCuenta().equals(request.getDestino().getTarjeta()))
			throw new MessageException(1100, HttpStatus.BAD_REQUEST);
		
		
		MB03Response mb03Response = transferenciaDAO.ejecutaTXMB03Transferencia(creaBeanMb03(request));
		respuestaTO.setCodigoRetorno(mb03Response.getCodigoRetorno());
		respuestaTO.setSecuencia(mb03Response.getNumSecuencia());
		respuestaTO.setReferencia(mb03Response.getNumReferencia());
		respuestaTO.setClaveRastreo(mb03Response.getAdrs());
		response.setResultado(respuestaTO);
		/** Falta el telefono adicional por falta de SmsRedCobroFacil **/
		frecuentesComponent.incrementaContador(request.getOrigen().getIcu(), request.getDestino().getConcepto().replace("\n", " "), mb03Response);

		transferenciaDAO.guardaOperacion(request);
		
		return new ResponseEntity<>(response, HttpStatus.CREATED);
	}

	/**
	 * Metodo que obtiene la informaci�n de un tipo de tarjeta
	 * @param icuCliente
	 * @param tarjetaDestino
	 * @return
	 */
	private InformacionTarjetaBean obtieneInfoTarjeta(String icuCliente, String tarjetaDestino)
	{
		InformacionTarjetaBean infoTarjeta = new InformacionTarjetaBean();
		CuentaTO cuenta=new CuentaTO();
		
		MB08Response mb08Response = transferenciaDAO.ejecutaTXMB08InfoTarjeta(icuCliente, tarjetaDestino);
		cuenta.setTarjeta(tarjetaDestino);
        cuenta.setBanco(WordUtils.capitalize(mb08Response.getBanco() != null ? mb08Response.getBanco().toLowerCase().trim() : ""));
        cuenta.setTipo(mb08Response.getTipoCuenta());
        cuenta.setTipoTarjeta(mb08Response.getTipoTarjeta());
        if(Validations.isNumerico(mb08Response.getIdBanco()))
        	cuenta.setIdBanco(Integer.parseInt(mb08Response.getIdBanco()));
        
        infoTarjeta.setNombre(mb08Response.getNombre());
        infoTarjeta.setApellidoPaterno(mb08Response.getApellidoP());
        infoTarjeta.setApellidoMaterno(mb08Response.getApellidoM());
        
        infoTarjeta.setCuenta(cuenta);
        
        return infoTarjeta;
	}
	
	/**
	 * Metodo que valida si existe monto limitado para la ejecuci�n de la transferencia
	 * @param request
	 * @return
	 */
	private boolean montoLimitado(ComisionRequest request) {
		boolean montoLimitado = true;
		String opcion = (request.getFechaOperacion() == null ? TransferenciasConstants.FECHA_HABIL_ACTUAL : TransferenciasConstants.FECHA_HABIL_FUTURA);
		F755Response f755Response = transferenciaDAO.ejecutaTXF755MontoLimitado(opcion, request.getFechaOperacion());
		if (f755Response.getBanderaLibre().equals("N"))
			throw new MessageException(1101, HttpStatus.INTERNAL_SERVER_ERROR);
		if ((opcion.equals(TransferenciasConstants.FECHA_HABIL_ACTUAL) 
				&& TransferenciasUtils.formateaFechaDatetoString(new Date(), TransferenciasConstants.FECHA_YYYYMMDD).equals(f755Response.getFechaSpei().trim()) 
				&& !f755Response.getBanderaPagoMovil().equals("M")) 
				|| (opcion.equals(TransferenciasConstants.FECHA_HABIL_FUTURA) 
						&& f755Response.getBanderaPagoMovil().equalsIgnoreCase("H")))
			montoLimitado = false;
		
		LOG.info("Operacion en horario {}disponible", (montoLimitado ? "NO " : ""));
		return montoLimitado;
	}
	
	private MB03Request creaBeanMb03(TransferenciaRequest request) {
		MB03Request mb03Request = new MB03Request();
		String descripcion = null;
		mb03Request.setIcuCliente(request.getOrigen().getIcu());
		mb03Request.setCuentaOrigen(request.getOrigen().getCuenta());
		mb03Request.setCuentaDestino(request.getDestino().getTarjeta());
		mb03Request.setMonto(request.getDestino().getMonto());
		mb03Request.setNumReferencia(request.getDestino().getReferencia());
		mb03Request.setFirmaDigital(request.getOrigen().getFirmaDigital());
		mb03Request.setFechaProgramada(TransferenciasUtils.formateaFechaStringtoDate(request.getDestino().getFechaOperacion(), TransferenciasConstants.FECHA_DDMMYYYY));
		mb03Request.setConceptoEnvio(request.getDestino().getConcepto().replace("\n", " "));
		mb03Request.setLatitud(request.getOrigen().getLatitud());
		mb03Request.setLongitud(request.getOrigen().getLongitud());		
		descripcion = TransferenciasUtils.stringRfc(request.getOrigen().getRfc()) + (Validations.isNullOrEmpty(request.getDestino().getDescripcion()) ? "" : request.getDestino().getDescripcion());
		mb03Request.setDescripcion(descripcion);
		return mb03Request;
	}
	
	
	public  boolean isNumerico(Object data) {
		try {
			return Pattern.matches("\\d*", data.toString());
		} catch (PatternSyntaxException e) {
			return false;
		}
	}
	
	public  boolean validaFormatoFecha(Object fecha, String format)
	{
		SimpleDateFormat formato=new SimpleDateFormat(format);
	
		try
		{
			formato.setLenient(false);
			formato.parse(fecha.toString());
		}catch(ParseException e){
			return false;
		}
	
		return true;
	}
	
	
	
}
