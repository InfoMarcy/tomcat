package com.bancoazteca.api.entity.frecuentes.editar;

import javax.validation.Valid;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

import com.bancoazteca.bdm.commons.utils.bean.RequestTO;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

/**
 * Request para la modificaci�n de una cuenta frecuente del cliente
 * @author B53678
 *
 */
@ApiModel("EditarFrecuenteRequest")
public class EditarFrecuenteRequest extends RequestTO
{
	@NotBlank(message="El ICU es requerido para la operación.")
	@Pattern(regexp="([a-fA-F0-9_-]){32,32}$", message="ICU invalido. Favor validar que los datos introducidos sean correctos.")
	@ApiModelProperty(required=true, example="3d900fc71f5433aafca5c0a2772cac4", notes="Icu del cliente")
	private String icu;
	
	@NotBlank(message="La firma digital es requerida para la operación.")
	@ApiModelProperty(required=true, example="000001", notes="Firma Digital del cliente")
	private String firmaDigital;
	
	@Valid
	@NotNull(message="El Objeto Detalle es requerido para la operación.")
	@ApiModelProperty(required=true, notes="Detalles de cambios en la frecuente")
	private EditarFrecuenteDetalleTO detalle;

	public String getIcu() {
		return icu;
	}

	public void setIcu(String icu) {
		this.icu = icu;
	}

	public String getFirmaDigital() {
		return firmaDigital;
	}

	public void setFirmaDigital(String firmaDigital) {
		this.firmaDigital = firmaDigital;
	}

	public EditarFrecuenteDetalleTO getDetalle() {
		return detalle;
	}

	public void setDetalle(EditarFrecuenteDetalleTO detalle) {
		this.detalle = detalle;
	}
}
