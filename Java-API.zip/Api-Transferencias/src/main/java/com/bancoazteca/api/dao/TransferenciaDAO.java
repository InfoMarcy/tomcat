package com.bancoazteca.api.dao;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.core.task.AsyncTaskExecutor;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.geo.GeoJsonPoint;
import org.springframework.stereotype.Component;

import com.bancoazteca.api.entity.DatosBancoBean;
import com.bancoazteca.api.entity.transferencias.TransferenciaRequest;
import com.bancoazteca.api.entity.transferencias.comision.ComisionRequest;
import com.bancoazteca.api.utilerias.ClaveOperacionComisionEnum;
import com.bancoazteca.api.utilerias.TransferenciasConstants;
import com.bancoazteca.api.utilerias.TransferenciasUtils;
import com.bancoazteca.bdm.commons.utils.enums.SistemasTerceros;
import com.bancoazteca.bdm.commons.utils.operaciones.OperacionEntity;
import com.bancoazteca.bdm.commons.utils.operaciones.ThreadOperaciones;
import com.bancoazteca.bdm.commons.utils.operaciones.enums.TipoOperacion;
import com.bancoazteca.bdm.commons.utils.validacodigo.ValidadorRespuestaUtils;
import com.bancoazteca.ms.alnova.business.AlnovaWorker;
import com.bancoazteca.ms.alnova.dao.terminales.TerminalesDAO;
import com.bancoazteca.ms.alnova.entity.beans.transaccion.f755.F755Request;
import com.bancoazteca.ms.alnova.entity.beans.transaccion.f755.F755Response;
import com.bancoazteca.ms.alnova.entity.beans.transaccion.mb03.MB03Request;
import com.bancoazteca.ms.alnova.entity.beans.transaccion.mb03.MB03Response;
import com.bancoazteca.ms.alnova.entity.beans.transaccion.mb08.MB08Request;
import com.bancoazteca.ms.alnova.entity.beans.transaccion.mb08.MB08Response;
import com.bancoazteca.ms.alnova.entity.beans.transaccion.mb18.MB18Request;
import com.bancoazteca.ms.alnova.entity.beans.transaccion.mb18.MB18Response;
import com.bancoazteca.ms.alnova.entity.beans.transaccion.mb42.MB42Request;
import com.bancoazteca.ms.alnova.entity.beans.transaccion.mb42.MB42Response;
import com.bancoazteca.ms.alnova.entity.terminal.TerminalEntity;
import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;

/**
 * @author Cesar M Orozco R
 *
 */
@Component
public class TransferenciaDAO {
	
	private static final Logger LOG = LoggerFactory.getLogger(TransferenciaDAO.class);
	
	@Autowired
	AlnovaWorker alnovaWorker;
	
	@Autowired
	TerminalesDAO terminalesDAO;
	
	@Autowired
	MongoTemplate mongoTemplate;
	
	@Autowired
    ValidadorRespuestaUtils validadorCodigoRespuesta;
	
	@Autowired
	@Qualifier("executorTaskLowPriority")
	AsyncTaskExecutor executor;
	
	/**
	 * Metodo que realiza la consulta de los catalogo de banco con alnova
	 * @return List<DatosBancoBean>
	 */
    //@HystrixCommand(commandKey="transferencias")
	public List<DatosBancoBean> ejecutaTXMB42CatalogoBancos(){
		List<DatosBancoBean> catalogoBancos = new ArrayList<>();
		MB42Response mb42Response = new MB42Response();
		MB42Request mb42Request = new MB42Request();		
		String usuario = alnovaWorker.obtenerUsuario(TransferenciasConstants.APLICACION_DEFECTO);
		TerminalEntity terminalEntity = terminalesDAO.obtenerTerminalConversacional(usuario);
		mb42Request.setTipoOperacion(TransferenciasConstants.TIPO_OPERACION_MB42);
		mb42Request.setOpcion(TransferenciasConstants.OPCION_MB42);
		mb42Request.setPaginacion(TransferenciasConstants.PAGINACION_INICIAL_MB42);
		try {
			do {
				mb42Response = alnovaWorker.ejecutarTransaccion(mb42Request, MB42Response.class, terminalEntity, usuario);
				mb42Response.getListaMb42Beans().stream().forEach(l -> {
					DatosBancoBean catalogoBanco = new DatosBancoBean();
					String codigoBanco = null;
					codigoBanco = l.getCodigoBanco();
					catalogoBanco.setCodigoBanco(codigoBanco);
					catalogoBanco.setNombreCorto(l.getNombreCorto());
                    catalogoBanco.setNombreLargo(l.getNombreLargo());
                    catalogoBancos.add(catalogoBanco);
                    mb42Request.setPaginacion(l.getCampoLibre());
				});
				if(mb42Request.getPaginacion() == null || mb42Request.getPaginacion().equals(TransferenciasConstants.PAGINACION_FINAL_MB42))
					break;
			}while(!mb42Response.getCodigo().equalsIgnoreCase(TransferenciasConstants.CODIGO_FIN_LISTA_MB42) && !mb42Response.getMensaje().contains(TransferenciasConstants.MENSAJE_FINAL_LISTA_MB42));
		}finally {
			liberarTerminal(terminalEntity);
		}
		return catalogoBancos;
	}
	
	/**
	 * Metodo que consulta la informacion de la tarjeta destino
	 * @param icuCliente
	 * @param tarjetaDestino
	 * @return MB08Response
	 */
    //@HystrixCommand(commandKey="transferencias")
	public MB08Response ejecutaTXMB08InfoTarjeta(String icuCliente, String tarjetaDestino) {	
    	String usuario = alnovaWorker.obtenerUsuario(TransferenciasConstants.APLICACION_DEFECTO);
		TerminalEntity terminalEntity = terminalesDAO.obtenerTerminalNoConversacional(usuario);
		MB08Request mb08Request = new MB08Request();
		mb08Request.setTarjeta(tarjetaDestino);
		mb08Request.setIdBDM(icuCliente);
		MB08Response mb08Response = alnovaWorker.ejecutarTransaccion(mb08Request, MB08Response.class, terminalEntity, usuario);
		validadorCodigoRespuesta.validarCodigo(mb08Response.getCodigo(), TransferenciasConstants.MB08, SistemasTerceros.ALNOVA);
		liberarTerminal(terminalEntity);
		return mb08Response;
	}
	
	/**
	 * Metodo que consulta la consulta de comision
	 * @param request
	 * @return MB18Response
	 */
    //@HystrixCommand(commandKey="transferencias")
	public MB18Response ejecutaTXMB18Comision(ComisionRequest request) {
		MB18Request mb18Request = new MB18Request();
		String usuario = alnovaWorker.obtenerUsuario(TransferenciasConstants.APLICACION_DEFECTO);
		TerminalEntity terminalEntity = terminalesDAO.obtenerTerminalNoConversacional(usuario);
		mb18Request.setClaveOperacion(ClaveOperacionComisionEnum.TRANSFERENCIA.getClave());
		mb18Request.setCuentaDestino(request.getCuentaDestino());
		mb18Request.setCuentaOrigen(request.getCuentaOrigen());
		mb18Request.setiCu(request.getIcu());
		mb18Request.setNumeroCelular(request.getCelular());
		mb18Request.setIdCelular(request.getIdCelular());
		MB18Response mb18Response = alnovaWorker.ejecutarTransaccion(mb18Request, MB18Response.class, terminalEntity, usuario);
		liberarTerminal(terminalEntity);
		return mb18Response;
	}
	
	/**
	 * Metodo que consulta el limite del monto a enviar
	 * @param opcion
	 * @param fechaOperacion
	 * @return F755Response
	 */
    //@HystrixCommand(commandKey="transferencias")
	public F755Response ejecutaTXF755MontoLimitado(String opcion, String fechaOperacion) {
		F755Request f755Request = new F755Request();
		String usuario = alnovaWorker.obtenerUsuario(TransferenciasConstants.APLICACION_DEFECTO);
		TerminalEntity terminalEntity = terminalesDAO.obtenerTerminalNoConversacional(usuario);
		f755Request.setOpcion(opcion);
		if(opcion.equalsIgnoreCase(TransferenciasConstants.FECHA_HABIL_FUTURA)) {
			f755Request.setFechanicial(TransferenciasUtils.formateaFechaStringtoDate(fechaOperacion, TransferenciasConstants.FECHA_DDMMYYYY));
			f755Request.setNumeroDias(TransferenciasConstants.NUMERODIAS);
		}
		F755Response f755Response = alnovaWorker.ejecutarTransaccion(f755Request, F755Response.class, terminalEntity, usuario);
		validadorCodigoRespuesta.validarCodigo(f755Response.getCodigo(), TransferenciasConstants.F755, SistemasTerceros.ALNOVA);
		liberarTerminal(terminalEntity);
		return f755Response;
	}
	
	/**
	 * Metodo que realiza la transferencia de dinero
	 * @param mb03Request
	 * @return MB03Response
	 */
    //@HystrixCommand(commandKey="transferencias")
	public MB03Response ejecutaTXMB03Transferencia(MB03Request mb03Request) {
		String usuario = alnovaWorker.obtenerUsuario(TransferenciasConstants.APLICACION_DEFECTO);
		TerminalEntity terminalEntity = terminalesDAO.obtenerTerminalNoConversacional(usuario);
		MB03Response mb03Response = alnovaWorker.ejecutarTransaccion(mb03Request, MB03Response.class, terminalEntity, usuario);
		
		
		
		System.out.println("Codigo Error MB03 => " + mb03Response.getCodigo());
		

		
		
		
		validadorCodigoRespuesta.validarCodigo(mb03Response.getCodigo(), TransferenciasConstants.MB03, SistemasTerceros.ALNOVA);
		liberarTerminal(terminalEntity);
		return mb03Response;
	}
	
	
	/**
	 * Metodo que guarda cada operacion que realiza el cliente de envio a cuenta
	 * @param request
	 */
    //@HystrixCommand(commandKey="transferencias")
	public void guardaOperacion(TransferenciaRequest request) {
		OperacionEntity operacionEntity = new OperacionEntity();
		operacionEntity.setUsuario(request.getOrigen().getIcu());
		operacionEntity.setFechaOperacion(TransferenciasUtils.formateaFechaStringtoDate(request.getDestino().getFechaOperacion(), TransferenciasConstants.FECHA_DDMMYYYY));
		operacionEntity.setGps(new GeoJsonPoint(request.getOrigen().getLongitud(), request.getOrigen().getLatitud()));
		operacionEntity.setTipo(TipoOperacion.ENVIO_CUENTA.getNum());		
		ThreadOperaciones operaciones = new ThreadOperaciones(operacionEntity, mongoTemplate, request.getOrigen().getLongitud(), request.getOrigen().getLatitud());
		executor.execute((Runnable)operaciones);
	}
	
	//@HystrixCommand(commandKey="transferencias")
	private void liberarTerminal(TerminalEntity terminal) {
		if(terminal != null && terminal.getTerminal() != null){
			LOG.info("Liberando Terminal No Conversacional:: {} ", terminal.getTerminal());
			terminalesDAO.liberarTerminal(terminal.getTerminal());
		}
	}

}
