package com.bancoazteca.api.entity.frecuentes.consulta;

import java.util.List;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

@ApiModel("ConsultaFrecuentesResultadoTO")
public class ConsultaFrecuentesResultadoTO
{
	@ApiModelProperty(notes="Lista de las frecuentes del cliente")
	private List<ConsultaFrecuenteTO> frecuentes;

	public List<ConsultaFrecuenteTO> getFrecuentes() {
		return frecuentes;
	}

	public void setFrecuentes(List<ConsultaFrecuenteTO> frecuentes) {
		this.frecuentes = frecuentes;
	}
}
