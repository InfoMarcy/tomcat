package com.bancoazteca.api.entity.transferencias;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

@ApiModel("TransferenciaRespuestaTO")
public class TransferenciaRespuestaTO
{
	@ApiModelProperty(example="569652", notes="Codigo de Retorno")
	private String codigoRetorno;
	
	@ApiModelProperty(example="999965", notes="numero de secuencia")
	private String secuencia;
	
	@ApiModelProperty(example="00025636", notes="Referencia de la transferencia")
	private String referencia;
	
	@ApiModelProperty(example="JJD545454545454544I", notes="clabe de rastreo de la transferencia")
	private String claveRastreo;

	public String getCodigoRetorno() {
		return codigoRetorno;
	}

	public void setCodigoRetorno(String codigoRetorno) {
		this.codigoRetorno = codigoRetorno;
	}

	public String getSecuencia() {
		return secuencia;
	}

	public void setSecuencia(String secuencia) {
		this.secuencia = secuencia;
	}

	public String getReferencia() {
		return referencia;
	}

	public void setReferencia(String referencia) {
		this.referencia = referencia;
	}

	public String getClaveRastreo() {
		return claveRastreo;
	}

	public void setClaveRastreo(String claveRastreo) {
		this.claveRastreo = claveRastreo;
	}
}
