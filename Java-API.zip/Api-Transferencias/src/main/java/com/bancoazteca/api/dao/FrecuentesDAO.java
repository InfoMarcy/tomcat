package com.bancoazteca.api.dao;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.data.domain.Sort;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;

import com.bancoazteca.api.entity.documents.FrecuenteTransferenciaEntity;
import com.bancoazteca.api.utilerias.OpcionConsultarEnum;
import com.bancoazteca.api.utilerias.TransferenciasConstants;
import com.bancoazteca.bdm.commons.utils.Validations;
import com.bancoazteca.bdm.commons.utils.exception.MessageException;

@Component
public class FrecuentesDAO {
	
	@Autowired
	@Qualifier("primaryMongoTemplate")
	MongoTemplate mongoTemplate;
	
	//@HystrixCommand(commandKey="transferencias")
	public void guardaFrecuente(FrecuenteTransferenciaEntity entity) {
		mongoTemplate.save(entity);
	}
	
	//@HystrixCommand(commandKey="transferencias")
	public void reactivarFrecuente(FrecuenteTransferenciaEntity entity) {
		Query query = new Query(Criteria.where(TransferenciasConstants.ID_FREQ).is(entity.getId()));
		Update update = new Update();
		update.set(TransferenciasConstants.ACTIVA, true);
		update.set(TransferenciasConstants.HOLOGRAMA, true);
		update.set(TransferenciasConstants.AVISO, false);
		update.set(TransferenciasConstants.NUM_OPERACIONES, 0);
		update.set(TransferenciasConstants.ALIAS, entity.getAlias());
		update.set(TransferenciasConstants.NOMBRE, entity.getNombre());
		update.set(TransferenciasConstants.APELLIDO_PATERNO, entity.getApPaterno());
		update.set(TransferenciasConstants.APELLIDO_MATERNO, entity.getApMaterno());
		update.set(TransferenciasConstants.FECHA_MOD, new Date());
		if(!Validations.isNullOrEmpty(entity.getEmail())) {
			update.set(TransferenciasConstants.EMAIL, entity.getEmail());
		}
		mongoTemplate.updateFirst(query, update, FrecuenteTransferenciaEntity.class);		
	}
	
	//@HystrixCommand(commandKey="transferencias")
	public void cambiarEstatusHolograma(String idFrecuente) {		
		Update update = new Update();
		update.set(TransferenciasConstants.HOLOGRAMA, true);				
		mongoTemplate.updateFirst(new Query(Criteria.where(TransferenciasConstants.ID_FREQ).is(idFrecuente)), update, FrecuenteTransferenciaEntity.class);
	}
	
	//@HystrixCommand(commandKey="transferencias")
	public List<FrecuenteTransferenciaEntity> consultaFrecuentes(String icuCliente, OpcionConsultarEnum opcionConsulta) {
		Query query = new Query();
		Criteria criteria = Criteria.where(TransferenciasConstants.USUARIO).is(icuCliente);		
		if(opcionConsulta == OpcionConsultarEnum.BANCOAZTECA)
			criteria.and(TransferenciasConstants.ID_BANCO).is(TransferenciasConstants.ID_BANCO_AZTECA);
		else if(opcionConsulta == OpcionConsultarEnum.OTROS)
			criteria.and(TransferenciasConstants.ID_BANCO).ne(TransferenciasConstants.ID_BANCO_AZTECA);
		criteria.and(TransferenciasConstants.ACTIVA).is(true);
		query.addCriteria(criteria);
		query.with(new Sort(Sort.Direction.DESC, TransferenciasConstants.NUM_OPERACIONES));
		query.fields().exclude(TransferenciasConstants.ACTIVA).exclude(TransferenciasConstants.USUARIO).exclude(TransferenciasConstants.DIA_NOT);		
		return mongoTemplate.find(query, FrecuenteTransferenciaEntity.class);
	}
	
	//@HystrixCommand(commandKey="transferencias")
	public void incrementarContador(String usuario,String destino, String importe, String concepto, String referencia) {
		Update update = new Update();
		update.inc(TransferenciasConstants.NUM_OPERACIONES, 1);
		update.set(TransferenciasConstants.IMPORTE, importe);
		update.set(TransferenciasConstants.CONCEPTO, concepto);
		update.set(TransferenciasConstants.REFERENCIA, referencia);
		update.set(TransferenciasConstants.FECHA_ULT_PAGO, new Date());
		Query query= new Query(Criteria.where(TransferenciasConstants.USUARIO).is(usuario).and(TransferenciasConstants.DESTINO).is(destino));
		mongoTemplate.updateFirst(query, update, FrecuenteTransferenciaEntity.class);
	}
	
	//@HystrixCommand(commandKey="transferencias")
	public void editaFrecuente(FrecuenteTransferenciaEntity entity) {
		Update update=new Update();
		update.set(TransferenciasConstants.FECHA_MOD, new Date());
		
		if(!Validations.isNullOrEmpty(entity.getEmail())) {
			update.set(TransferenciasConstants.EMAIL, entity.getEmail());
		}
		if(!Validations.isNullOrEmpty(entity.getAlias())) {
			update.set(TransferenciasConstants.ALIAS, entity.getAlias());
		}
		Query query = new Query(Criteria.where(TransferenciasConstants.ID_FREQ).is(entity.getId()));
		
		
		if(mongoTemplate.updateFirst(query, update, FrecuenteTransferenciaEntity.class).getModifiedCount() == 0) {
			throw new MessageException(1104, HttpStatus.NOT_FOUND);
		}
			
	}
	
	//@HystrixCommand(commandKey="transferencias")
	public void eliminaFrecuente(String idFrecuentes, String icu) {
		Update update=new Update();			
		update.set(TransferenciasConstants.FECHA_MOD, new Date());
		update.set(TransferenciasConstants.ACTIVA,false);
		update.set(TransferenciasConstants.AVISO, false);
		update.set(TransferenciasConstants.HOLOGRAMA, false);
		update.set(TransferenciasConstants.NUM_OPERACIONES, 0);
		Query query = new Query(Criteria.where(TransferenciasConstants.ID_FREQ).is(idFrecuentes).and(TransferenciasConstants.USUARIO).is(icu));
		mongoTemplate.updateFirst(query, update, FrecuenteTransferenciaEntity.class);
	}
	
	//@HystrixCommand(commandKey="transferencias")
	public FrecuenteTransferenciaEntity recuperaFrecuente(String destino, String usuario){		
		Query find = new Query(Criteria.where(TransferenciasConstants.USUARIO).is(usuario).and(TransferenciasConstants.DESTINO).is(destino));				
		return mongoTemplate.findOne(find, FrecuenteTransferenciaEntity.class);
	}
	
	//@HystrixCommand(commandKey="transferencias")
	public FrecuenteTransferenciaEntity recuperaFrecuente(String idFrecuente){		
		Query find = new Query(Criteria.where(TransferenciasConstants.ID_FREQ).is(idFrecuente));				
		return mongoTemplate.findOne(find, FrecuenteTransferenciaEntity.class);
	}
	
	//@HystrixCommand(commandKey="transferencias")
	public FrecuenteTransferenciaEntity recuperaICU(String icu){		
		Query find = new Query(Criteria.where(TransferenciasConstants.USUARIO).is(icu));				
		return mongoTemplate.findOne(find, FrecuenteTransferenciaEntity.class);
	}
	
	
}
