package com.bancoazteca.api.entity.frecuentes.alta;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Pattern;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

@ApiModel("NuevoFrecuenteTitularTO")
public class NuevaFrecuenteTitularTO
{
	@NotBlank(message="El nombre es requerido para la operación.")
	@Pattern(regexp="([a-zA-Z ]){2,20}+$", message="El nombre debe tener mínimo 2 caracteres y máximo 20. No se aceptan caracteres especiales.")
	@ApiModelProperty(example="Cesar Miguel", notes="Nombre del frecuente destino", required=true)
	private String nombre;
	
	@NotBlank(message="El apellido paterno es requerido para la operación.")
	@Pattern(regexp="([a-zA-Z ]){2,20}+$", message="El apellido paterno debe tener mínimo 2 caracteres y máximo 20. No se aceptan caracteres especiales.")
	@ApiModelProperty(example="Orozco", notes="Apellido paterno del frecuente destino", required=true)
	private String apellidoPaterno;
	

	@Pattern(regexp="([a-zA-Z ]){0,20}+$", message="El apellido materno debe tener máximo 20 caracteres. No se aceptan caracteres especiales.")
	@ApiModelProperty(example="De la Croa", notes="Apellido Materno del frecuente destino", required=true)
	private String apellidoMaterno;

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String getApellidoPaterno() {
		return apellidoPaterno;
	}

	public void setApellidoPaterno(String apellidoPaterno) {
		this.apellidoPaterno = apellidoPaterno;
	}

	public String getApellidoMaterno() {
		return apellidoMaterno;
	}

	public void setApellidoMaterno(String apellidoMaterno) {
		this.apellidoMaterno = apellidoMaterno;
	}
}
