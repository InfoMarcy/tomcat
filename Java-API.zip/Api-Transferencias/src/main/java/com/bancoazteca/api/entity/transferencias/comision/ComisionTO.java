package com.bancoazteca.api.entity.transferencias.comision;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

@ApiModel("ComisionTO")
public class ComisionTO
{
	@ApiModelProperty(notes="Comision de la transferencia con formato y encriptado Alnova", example="hjWD8gbYPSMv64FCtnQMDqVjZHArUYEFXL0q3SzFK1w")
	private String comision;
	
	@ApiModelProperty(notes="Informacion de la tarjeta destino")
	private InformacionTarjetaBean destinatario;
	
	@ApiModelProperty(notes="Indica si el monto esta limitado por dia inhabil o festivo", example="false")
	private boolean montoLimitado;

	public String getComision() {
		return comision;
	}

	public void setComision(String comision) {
		this.comision = comision;
	}

	public InformacionTarjetaBean getDestinatario() {
		return destinatario;
	}

	public void setDestinatario(InformacionTarjetaBean destinatario) {
		this.destinatario = destinatario;
	}

	public boolean isMontoLimitado() {
		return montoLimitado;
	}

	public void setMontoLimitado(boolean montoLimitado) {
		this.montoLimitado = montoLimitado;
	}
}
