package com.bancoazteca.api.entity.transferencias.comision;

import com.bancoazteca.bdm.commons.utils.bean.ResponseTO;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

/**
 * 
 * @author B53678
 *
 */
@ApiModel(value="ComisionResponse", description="Clase response para la consulta de comisiones por transferencia")
public class ComisionResponse extends ResponseTO
{
	@ApiModelProperty(value="resultado", notes="Objeto con la informacion de la comision por la transferencia")
	private ComisionTO resultado;

	public ComisionTO getResultado() {
		return resultado;
	}

	public void setResultado(ComisionTO resultado) {
		this.resultado = resultado;
	}
}
