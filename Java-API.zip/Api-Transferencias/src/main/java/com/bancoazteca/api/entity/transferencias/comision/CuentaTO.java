package com.bancoazteca.api.entity.transferencias.comision;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

@ApiModel("CuentaTO")
public class CuentaTO
{
	@ApiModelProperty(example="GUARDADITO DIGITAL", notes="Tipo de producto destino, Solo aplica en BAZ")
	private String tipo;
	
	@ApiModelProperty(example="u5_bBpxYLD4xgntYGtpdzg==", notes="Numero de tarjeta, solo devuelta cuando se tiene la informacion")
	private String tarjeta;
	
	@ApiModelProperty(example="DEBITO", notes="Tipo de tarjeta/Cta")
	private String tipoTarjeta;
	
	@ApiModelProperty(example="127", notes="Identificador del banco destino")
	private int idBanco;	

	@ApiModelProperty(example="BANCO AZTECA", notes="Nombre del banco Destino")
	private String banco;

	public String getTipo() {
		return tipo;
	}

	public void setTipo(String tipo) {
		this.tipo = tipo;
	}

	public String getTarjeta() {
		return tarjeta;
	}

	public void setTarjeta(String tarjeta) {
		this.tarjeta = tarjeta;
	}

	public String getTipoTarjeta() {
		return tipoTarjeta;
	}

	public void setTipoTarjeta(String tipoTarjeta) {
		this.tipoTarjeta = tipoTarjeta;
	}

	public int getIdBanco() {
		return idBanco;
	}

	public void setIdBanco(int idBanco) {
		this.idBanco = idBanco;
	}

	public String getBanco() {
		return banco;
	}

	public void setBanco(String banco) {
		this.banco = banco;
	}
}
