package com.bancoazteca.api.entity.frecuentes.alta;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

@ApiModel("NuevoFrecuenteTO")
public class NuevaFrecuenteTO
{
	
	
	@Valid
	@NotNull(message="El Objeto Titular es requerido para la operación.")
	@ApiModelProperty(value="titular", notes="Datos del frecuente", required=true)
	private NuevaFrecuenteTitularTO titular;
	

	@Valid
	@NotNull(message="El Objeto Cuenta es requerido para la operación.")
	@ApiModelProperty(notes="Informacion de la cta/clabe/tarjeta/telefono de la frecuente", required=true)
	private NuevaFrecuenteCuentaTO cuenta;

	public NuevaFrecuenteTitularTO getTitular() {
		return titular;
	}

	public void setTitular(NuevaFrecuenteTitularTO titular) {
		this.titular = titular;
	}

	public NuevaFrecuenteCuentaTO getCuenta() {
		return cuenta;
	}

	public void setCuenta(NuevaFrecuenteCuentaTO cuenta) {
		this.cuenta = cuenta;
	}
}
