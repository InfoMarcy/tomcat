package com.bancoazteca.api.entity.transferencias;

import com.bancoazteca.bdm.commons.utils.bean.ResponseTO;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

/**
 * Response para el servicio de transferencias
 * @author B53678
 *
 */
@ApiModel("TransferenciaResponse")
public class TransferenciaResponse extends ResponseTO
{
	@ApiModelProperty(notes="resultado de la transferencia")
	private TransferenciaRespuestaTO resultado;

	public TransferenciaRespuestaTO getResultado() {
		return resultado;
	}

	public void setResultado(TransferenciaRespuestaTO resultado) {
		this.resultado = resultado;
	}
}
