package com.bancoazteca.api.entity.transferencias.comision;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

@ApiModel("InformacionTarjetaBean")
public class InformacionTarjetaBean
{
	@ApiModelProperty(example="OROZCO", notes="Apellido paterno del destino, No aplica para cuentas de otros bancos")
	private String apellidoPaterno;	
	
	@ApiModelProperty(example="RIVERA", notes="Apellido materno del destino, No aplica para cuentas de otros bancos")
	private String apellidoMaterno;
	
	@ApiModelProperty(example="CESAR MIGUEL", notes="Nombre del destino, No aplica para cuentas de otros bancos")
	private String nombre;
	
	@ApiModelProperty(notes="Informacion de la cuenta destino")
	private CuentaTO cuenta;

	public String getApellidoPaterno() {
		return apellidoPaterno;
	}

	public void setApellidoPaterno(String apellidoPaterno) {
		this.apellidoPaterno = apellidoPaterno;
	}

	public String getApellidoMaterno() {
		return apellidoMaterno;
	}

	public void setApellidoMaterno(String apellidoMaterno) {
		this.apellidoMaterno = apellidoMaterno;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public CuentaTO getCuenta() {
		return cuenta;
	}

	public void setCuenta(CuentaTO cuenta) {
		this.cuenta = cuenta;
	}
}
