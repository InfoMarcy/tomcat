package com.bancoazteca.api.entity.frecuentes.editar;

import javax.validation.constraints.Email;
import javax.validation.constraints.NotBlank;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

@ApiModel("EditarFrecuenteDetalleTO")
public class EditarFrecuenteDetalleTO
{
	@NotBlank(message="El ID del frecuente es requerido para la operación.")
	@ApiModelProperty(value="idFrecuente", required=true, example="5c4f5195718ab9617bb5100a")
	private String idFrecuente;
	
	@ApiModelProperty(value="alias", required=false, example="PAPA")
	private String alias;
	
	@Email(message="Favor de revisar su correo eléctronico, formato no valido.")
	@ApiModelProperty(value="correElectronico", required=false, example="corozcor@elektra.com.mx")
	private String correoElectronico;

	public String getIdFrecuente() {
		return idFrecuente;
	}

	public void setIdFrecuente(String idFrecuente) {
		this.idFrecuente = idFrecuente;
	}

	public String getAlias() {
		return alias;
	}

	public void setAlias(String alias) {
		this.alias = alias;
	}

	public String getCorreoElectronico() {
		return correoElectronico;
	}

	public void setCorreoElectronico(String correoElectronico) {
		this.correoElectronico = correoElectronico;
	}


}
