package com.bancoazteca.api.entity.frecuentes.bloqueo;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Pattern;

import com.bancoazteca.bdm.commons.utils.bean.RequestTO;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

@ApiModel("EliminarFrecuenteRequestTO")
public class BloquearFrecuenteRequestTO extends RequestTO
{
	@NotBlank(message="El ID del frecuente es requerido para la operación.")
	@ApiModelProperty(required=true, example="58ab7c07dff4bf235856728b", notes="Identificador de la frecuente a eliminar")
	private String idFrecuente;
	
	
	
	@NotBlank(message="El ICU es requerido para la operación.")
	@Pattern(regexp="([a-fA-F0-9_-]){32,32}$", message="ICU invalido. Favor validar que los datos introducidos sean correctos.")
	@ApiModelProperty(example="93d900fc71f5433aafca5c0a2772cac4", notes="El icu del cliente que registra la frecuente", required=true)
	private String icu;
	

	public String getIdFrecuente() {
		return idFrecuente;
	}

	public void setIdFrecuente(String idFrecuente) {
		this.idFrecuente = idFrecuente;
	}

	public String getIcu() {
		return icu;
	}

	public void setIcu(String icu) {
		this.icu = icu;
	}
	
	
}
