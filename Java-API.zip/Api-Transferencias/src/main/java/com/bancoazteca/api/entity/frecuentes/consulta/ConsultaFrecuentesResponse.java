package com.bancoazteca.api.entity.frecuentes.consulta;

import com.bancoazteca.bdm.commons.utils.bean.ResponseTO;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

/**
 * Response con las consulta de las frecuentes del cliente
 * @author B53678
 *
 */
@ApiModel("ConsultaFrecuentesResponse")
public class ConsultaFrecuentesResponse extends ResponseTO
{
	@ApiModelProperty(notes="Objeto con resultado de la consulta")
	private ConsultaFrecuentesResultadoTO resultado;

	public ConsultaFrecuentesResultadoTO getResultado() {
		return resultado;
	}

	public void setResultado(ConsultaFrecuentesResultadoTO resultado) {
		this.resultado = resultado;
	}
}
