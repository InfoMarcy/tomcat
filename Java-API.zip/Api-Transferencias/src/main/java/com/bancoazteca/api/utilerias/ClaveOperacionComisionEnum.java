package com.bancoazteca.api.utilerias;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonValue;

public enum ClaveOperacionComisionEnum {
	
	TRANSFERENCIA("SP"),
	PAGOTARJETA("PT"),
	DINEROEXPRESS("DE"),
	ENVIOINTERNACIONAL("EI"),
	ENVIOCELULAR("EC"),
	TIEMPOAIRE("TA"),
	PAGOSERVICIOS("PS"),
	RETIROATM("RA"),
	ENVIOATM("EA"),
	DEPOSITOCARGOTARJETA("PR"),
	TEF("TF");
	
	private String claveEnum;
	
	private ClaveOperacionComisionEnum(String clave) {
		this.claveEnum = clave;
	}
	
	@JsonCreator
	 public static ClaveOperacionComisionEnum create(String value){
		 for (ClaveOperacionComisionEnum claveDest : ClaveOperacionComisionEnum.values()){
			if (claveDest.toString().equals(value) || String.valueOf(claveDest.getClave()).equals(value)) {
				return claveDest;
			}
		}
		 return null;
	 }
	
	@JsonValue
	public String getClave() {
		return claveEnum;
	}



}
