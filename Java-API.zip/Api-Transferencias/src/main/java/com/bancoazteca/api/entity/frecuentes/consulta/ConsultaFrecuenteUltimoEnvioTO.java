package com.bancoazteca.api.entity.frecuentes.consulta;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

@ApiModel("ConsultaFrecuenteUltimoEnvioTO")
public class ConsultaFrecuenteUltimoEnvioTO
{
	@ApiModelProperty(notes="Fecha del ultimo envio a esta frecuente, formato dd/MM/yyyy", example="29/01/2019")
	private String fecha;
	
	@ApiModelProperty(notes="Concepto del ultimo envio a esta frecuente", example="PAGO DE RENTA")
	private String concepto;
	
	@ApiModelProperty(notes="Importe del ultimo envio a esta frecuente, encriptado con algoritmo y formato alnova", example="hjWD8gbYPSMv64FCtnQMDqVjZHArUYEFXL0q3SzFK1w")
	private String importe;
	
	@ApiModelProperty(notes="Referencia del ultimo envio a esta frecuente", example="35465")
	private String referencia;

	public String getFecha() {
		return fecha;
	}

	public void setFecha(String fecha) {
		this.fecha = fecha;
	}

	public String getConcepto() {
		return concepto;
	}

	public void setConcepto(String concepto) {
		this.concepto = concepto;
	}

	public String getImporte() {
		return importe;
	}

	public void setImporte(String importe) {
		this.importe = importe;
	}

	public String getReferencia() {
		return referencia;
	}

	public void setReferencia(String referencia) {
		this.referencia = referencia;
	}
}
