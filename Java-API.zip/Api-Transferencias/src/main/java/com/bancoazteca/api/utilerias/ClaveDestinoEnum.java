package com.bancoazteca.api.utilerias;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonValue;

public enum ClaveDestinoEnum {
	
	CLABE("CLB"),
	TARJETA("TRJ"),
	CUENTA("CTA"),
	TELEFONO("TEL");	
	
	private String claveEnum;
	
	private ClaveDestinoEnum(String clave) {
		this.claveEnum = clave;
	}

	@JsonCreator
	 public static ClaveDestinoEnum create(String value){
		 for (ClaveDestinoEnum claveDest : ClaveDestinoEnum.values()){
			if (claveDest.toString().equals(value) || String.valueOf(claveDest.getClave()).equals(value)) {
				return claveDest;
			}
		}
		 return null;
	 }
	
	@JsonValue
	public String getClave() {
		return claveEnum;
	}


}
