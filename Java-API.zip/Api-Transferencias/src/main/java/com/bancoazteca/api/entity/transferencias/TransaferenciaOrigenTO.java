package com.bancoazteca.api.entity.transferencias;

import javax.validation.constraints.NotBlank;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

@ApiModel("TransferenciaOrigenTO")
public class TransaferenciaOrigenTO
{
	
	@NotBlank(message="El ICU es requerido para la operación.")
	@ApiModelProperty(required=true, example = "5c5d2d8cf9774c34a061e0164b99644c", notes="Icu del cliente que realiza el envio")
	private String icu;
	
	@NotBlank(message="El RFC es requerido para la operación.")
	@ApiModelProperty(required=false, example = "OORC9310168X4", notes="RFC del cliente que realiza el envio, requerido solo para envios a otro banco")
	private String rfc;
	
	@NotBlank(message="El número de cuenta es requerida para la operación.")
	@ApiModelProperty(required=true, example = "ffYCEolAq36SF8qJbQwY9g==", notes="Cuenta origen a 14 digitos con encriptado Alnova")
	private String cuenta;
	
	
	@ApiModelProperty(required = false, example = "55.2563", notes="Latitud GPS")
	private double latitud;

	
	@ApiModelProperty(required = false, example = "-55.2563", notes="Longitud GPS")
	private double longitud;
	
	@NotBlank(message="La firma Digital es requerida para la operación.")
	@ApiModelProperty(required = true, example = "e7xtEkO4wFM54xm-ccgbfw==", notes="Firma digital del cliente, con encriptado alnova")
	private String firmaDigital;

	public String getIcu() {
		return icu;
	}

	public void setIcu(String icu) {
		this.icu = icu;
	}

	public String getRfc() {
		return rfc;
	}

	public void setRfc(String rfc) {
		this.rfc = rfc;
	}

	public String getCuenta() {
		return cuenta;
	}

	public void setCuenta(String cuenta) {
		this.cuenta = cuenta;
	}

	public double getLatitud() {
		return latitud;
	}

	public void setLatitud(double latitud) {
		this.latitud = latitud;
	}

	public double getLongitud() {
		return longitud;
	}

	public void setLongitud(double longitud) {
		this.longitud = longitud;
	}

	public String getFirmaDigital() {
		return firmaDigital;
	}

	public void setFirmaDigital(String firmaDigital) {
		this.firmaDigital = firmaDigital;
	}
}
