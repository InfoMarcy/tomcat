package com.bancoazteca.api.controller;

import java.io.UnsupportedEncodingException;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;

import javax.crypto.BadPaddingException;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.validation.Valid;
import javax.xml.bind.JAXBException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.bancoazteca.api.business.FrecuentesComponent;
import com.bancoazteca.api.entity.frecuentes.alta.AltaFrecuenteRequest;
import com.bancoazteca.api.entity.frecuentes.bloqueo.BloquearFrecuenteRequestTO;
import com.bancoazteca.api.entity.frecuentes.consulta.ConsultaFrecuentesRequest;
import com.bancoazteca.api.entity.frecuentes.consulta.ConsultaFrecuentesResponse;
import com.bancoazteca.api.entity.frecuentes.editar.EditarFrecuenteRequest;
import com.bancoazteca.bdm.commons.utils.bean.ResponseError;
import com.bancoazteca.bdm.commons.utils.bean.ResponseTO;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

/**
 * @author Cesar M Orozco R
 *
 */
@Api(value = "Api Transferencias")
@CrossOrigin
@RestController
@RequestMapping("/transferencias/v1/frecuentes/cuentas")
@Validated
public class FrecuentesController {

	@Autowired
	FrecuentesComponent frecuentesComponent;

	/**
	 * Controller que da de alta una cuenta frecuente
	 * 
	 * @param request
	 * @return ResponseEntity
	 */
	@ApiOperation(value = "Agrega una cuenta frecuente", nickname = "Agrega una cuenta frecuente", response = ResponseTO.class, tags = {
			"Api Transferencias" })
	@ApiResponses({ @ApiResponse(code = 201, message = "Creada", response = ResponseTO.class),
			@ApiResponse(code = 400, message = "Entrada incorrecta", response = ResponseError.class),
			@ApiResponse(code = 500, message = "Error inesperado", response = ResponseError.class) })
	@PostMapping(consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Object> agregaFrecuente(
			@Valid @RequestHeader(defaultValue="eyJhbGciOiJSUzM4NCIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIxMjM0NTY3ODkwIiwibmFtZSI6IkpvaG4gRG9lIiwiaWF0IjoxNTE2MjM5MDIyLCJIYXNoQ29kZSI6IjY0NTVlMDBjYjgxMWY5MjhhMjgwODNlNzQ1YTcxYjQ5MGYyYzRlYTY4MzE1MGU3MWY4NmQ1NjY4Y2VlODgyOTdkODVmM2ExZTNjZGY2ZTkxZmQ2NGI0YWZkYjEzMDg5M2Q4ZjI3MDY5YmZhNGQ2ZWZlZmM5ZWU1ZTNlZjE1YzBlIn0.bGDQoQTibydo10-EIOnI9cfSJUI2SsA3UUYbnn-0K9qRzL-kstxbe4cqBirh3-Gayjw0rrqkDKkeZi-4MCrGDx4tf2eaABQPsrbD0IixydOKT2DuIHOk383OkigCq9ppr1o9OUrwpsVn_W9QROIQRpQcWqgHsMdzY73j2Qv9oNI", name="Token", required=true) String token,
			@Valid @RequestBody AltaFrecuenteRequest request)
	{
		return frecuentesComponent.guardaFrecuente(request);
	}

	/**
	 * Edita la cuenta frecuente seleccionada
	 * 
	 * @param request
	 * @return ResponseEntity
	 * @throws JAXBException 
	 * @throws UnsupportedEncodingException 
	 * @throws InvalidAlgorithmParameterException 
	 * @throws BadPaddingException 
	 * @throws IllegalBlockSizeException 
	 * @throws NoSuchPaddingException 
	 * @throws NoSuchAlgorithmException 
	 * @throws InvalidKeyException 
	 */
	@ApiOperation(value = "Actualiza informaci�n de una cuenta frecuente", nickname = "Actualiza informaci�n de una cuenta frecuente", response = ResponseTO.class, tags = {
			"Api Transferencias" })
	@ApiResponses({ @ApiResponse(code = 200, message = "Ok", response = ResponseTO.class),
			@ApiResponse(code = 400, message = "Entrada incorrecta", response = ResponseError.class),
			@ApiResponse(code = 404, message = "No encontrado", response = ResponseError.class),
			@ApiResponse(code = 500, message = "Error inesperado", response = ResponseError.class) })
	@PutMapping(consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Object> editaFrecuente(
			@Valid @RequestHeader(defaultValue="eyJhbGciOiJSUzM4NCIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIxMjM0NTY3ODkwIiwibmFtZSI6IkpvaG4gRG9lIiwiaWF0IjoxNTE2MjM5MDIyLCJIYXNoQ29kZSI6IjY0NTVlMDBjYjgxMWY5MjhhMjgwODNlNzQ1YTcxYjQ5MGYyYzRlYTY4MzE1MGU3MWY4NmQ1NjY4Y2VlODgyOTdkODVmM2ExZTNjZGY2ZTkxZmQ2NGI0YWZkYjEzMDg5M2Q4ZjI3MDY5YmZhNGQ2ZWZlZmM5ZWU1ZTNlZjE1YzBlIn0.bGDQoQTibydo10-EIOnI9cfSJUI2SsA3UUYbnn-0K9qRzL-kstxbe4cqBirh3-Gayjw0rrqkDKkeZi-4MCrGDx4tf2eaABQPsrbD0IixydOKT2DuIHOk383OkigCq9ppr1o9OUrwpsVn_W9QROIQRpQcWqgHsMdzY73j2Qv9oNI", name="Token", required=true) String token,
			@Valid @RequestBody EditarFrecuenteRequest request) throws JAXBException
	{
		
		return frecuentesComponent.editaFrecuente(request);
	}

	/**
	 * Elimina la cuenta frecuente seleccionada
	 * 
	 * @param idFrecuente
	 * @param aplicacion
	 * @return
	 */	
	@ApiOperation(value = "Elimina una cuenta frecuente", nickname = "Elimina una cuenta frecuente", response = ResponseTO.class, tags = {
	"Api Transferencias" })
@ApiResponses({ @ApiResponse(code = 200, message = "Ok", response = ResponseTO.class),
		   @ApiResponse(code=400, message="Entrada incorrecta", response=ResponseError.class),
		   @ApiResponse(code=404, message="No encontrado", response=ResponseError.class),
	@ApiResponse(code = 500, message = "Error inesperado", response = ResponseError.class) })
@DeleteMapping(produces = MediaType.APPLICATION_JSON_VALUE)
public ResponseEntity<Object> eliminaFrecuente(
	@Valid @RequestHeader(defaultValue="eyJhbGciOiJSUzM4NCIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIxMjM0NTY3ODkwIiwibmFtZSI6IkpvaG4gRG9lIiwiaWF0IjoxNTE2MjM5MDIyLCJIYXNoQ29kZSI6IjY0NTVlMDBjYjgxMWY5MjhhMjgwODNlNzQ1YTcxYjQ5MGYyYzRlYTY4MzE1MGU3MWY4NmQ1NjY4Y2VlODgyOTdkODVmM2ExZTNjZGY2ZTkxZmQ2NGI0YWZkYjEzMDg5M2Q4ZjI3MDY5YmZhNGQ2ZWZlZmM5ZWU1ZTNlZjE1YzBlIn0.bGDQoQTibydo10-EIOnI9cfSJUI2SsA3UUYbnn-0K9qRzL-kstxbe4cqBirh3-Gayjw0rrqkDKkeZi-4MCrGDx4tf2eaABQPsrbD0IixydOKT2DuIHOk383OkigCq9ppr1o9OUrwpsVn_W9QROIQRpQcWqgHsMdzY73j2Qv9oNI", name="Token", required=true) String token,
	@Valid @RequestBody BloquearFrecuenteRequestTO request)
{
return frecuentesComponent.eliminaFrecuente(request.getIdFrecuente(), request.getIcu());
}
	
	
	/**
	 * Controller que consulta las frecuentes, catalogo de banco
	 * 
	 * @param request
	 * @return ResponseEntity
	 */
	@ApiOperation(value = "Consulta las cuentas frecuentes de un cliente", nickname = "Consulta las cuentas frecuentes de un cliente", response = ConsultaFrecuentesResponse.class, tags = {
			"Api Transferencias" })
	@ApiResponses({ @ApiResponse(code = 200, message = "Ok", response = ConsultaFrecuentesResponse.class),
				   @ApiResponse(code=404, message="No encontrado", response=ResponseError.class),
			@ApiResponse(code = 500, message = "Error inesperado", response = ResponseError.class) })
	@PostMapping(value = "/busquedas", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Object> consultaFrecuentes(
			@Valid @RequestHeader(defaultValue="eyJhbGciOiJSUzM4NCIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIxMjM0NTY3ODkwIiwibmFtZSI6IkpvaG4gRG9lIiwiaWF0IjoxNTE2MjM5MDIyLCJIYXNoQ29kZSI6IjY0NTVlMDBjYjgxMWY5MjhhMjgwODNlNzQ1YTcxYjQ5MGYyYzRlYTY4MzE1MGU3MWY4NmQ1NjY4Y2VlODgyOTdkODVmM2ExZTNjZGY2ZTkxZmQ2NGI0YWZkYjEzMDg5M2Q4ZjI3MDY5YmZhNGQ2ZWZlZmM5ZWU1ZTNlZjE1YzBlIn0.bGDQoQTibydo10-EIOnI9cfSJUI2SsA3UUYbnn-0K9qRzL-kstxbe4cqBirh3-Gayjw0rrqkDKkeZi-4MCrGDx4tf2eaABQPsrbD0IixydOKT2DuIHOk383OkigCq9ppr1o9OUrwpsVn_W9QROIQRpQcWqgHsMdzY73j2Qv9oNI", name="Token", required=true) String token,
			@Valid @RequestBody ConsultaFrecuentesRequest request)
	{
		return frecuentesComponent.consultaFrecuentes(request);
	}

}
