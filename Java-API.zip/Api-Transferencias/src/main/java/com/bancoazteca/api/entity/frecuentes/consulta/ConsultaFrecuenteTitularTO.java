package com.bancoazteca.api.entity.frecuentes.consulta;

import com.bancoazteca.api.entity.frecuentes.alta.NuevaFrecuenteTitularTO;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

@ApiModel("ConsultaFrecuenteTitularTO")
public class ConsultaFrecuenteTitularTO extends NuevaFrecuenteTitularTO
{
	@ApiModelProperty(notes="Correo electronico de la frecuente", example="test@test.com")
	private String correoElectronico;

	public String getCorreoElectronico() {
		return correoElectronico;
	}

	public void setCorreoElectronico(String correoElectronico) {
		this.correoElectronico = correoElectronico;
	}
}
