package com.bancoazteca.api.utilerias;

public enum OpcionConsultarEnum {
	
	TODAS,
	BANCOAZTECA,
	OTROS;
	
}
