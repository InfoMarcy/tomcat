package com.bancoazteca.api.entity.frecuentes.alta;

import javax.validation.Valid;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

import com.bancoazteca.bdm.commons.utils.bean.RequestTO;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

/**
 * Request para dar de alta una cuenta frecuente del cliente
 * @author B53678
 *
 */
@ApiModel("AltaFrecuenteRequest")
public class AltaFrecuenteRequest extends RequestTO{

	@NotBlank(message="El ICU es requerido para la operación.")
	@Pattern(regexp="([a-fA-F0-9_-]){32,32}$", message="ICU invalido. Favor validar que los datos introducidos sean correctos.")
	@ApiModelProperty(example="93d900fc71f5433aafca5c0a2772cac4", notes="El icu del cliente que registra la frecuente", required=true)
	private String icu;
	
	
	
	@Valid
	@NotNull(message="El Objeto Detalle es requerido para la operación.")
	@ApiModelProperty(notes="Detalle de la frecuente a dar de alta", required=true)
	private NuevaFrecuenteTO detalle;

	public String getIcu() {
		return icu;
	}

	public void setIcu(String icu) {
		this.icu = icu;
	}

	public NuevaFrecuenteTO getDetalle() {
		return detalle;
	}

	public void setDetalle(NuevaFrecuenteTO detalle) {
		this.detalle = detalle;
	}

}
