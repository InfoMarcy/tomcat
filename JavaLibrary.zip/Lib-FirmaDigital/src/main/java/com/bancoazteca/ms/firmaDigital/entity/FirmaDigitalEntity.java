package com.bancoazteca.ms.firmaDigital.entity;

import java.net.InetAddress;
import java.net.UnknownHostException;
import java.sql.Timestamp;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Pattern;
import javax.xml.bind.annotation.XmlRootElement;

import com.bancoazteca.bdm.commons.utils.properties.PropertiesManager;


@XmlRootElement(name = "autenticartoken_request")
public class FirmaDigitalEntity {
	private static final String strOperador = PropertiesManager.getInstance()
			.getProperty(FirmaDigitalConstantes.FIRMADIGITAL_PROPERTIES, FirmaDigitalConstantes.FIRMADIGITAL_OPERATOR);
	private static final String strPais = PropertiesManager.getInstance()
			.getProperty(FirmaDigitalConstantes.FIRMADIGITAL_PROPERTIES, FirmaDigitalConstantes.FIRMADIGITAL_PAIS);
	private static final String strSucursal = PropertiesManager.getInstance()
			.getProperty(FirmaDigitalConstantes.FIRMADIGITAL_PROPERTIES, FirmaDigitalConstantes.FIRMADIGITA_SUCURSAL);
	private static final String strTokenAcces = PropertiesManager.getInstance().getProperty(
			FirmaDigitalConstantes.FIRMADIGITAL_PROPERTIES, FirmaDigitalConstantes.FIRMADIGITA_TOKEN_ACCESS);

	@NotBlank(message = "El ICU es requerido para la operación.")
	@Pattern(regexp = "([a-fA-F0-9_-]){32,32}$", message = "ICU invalido. Favor validar que los datos introducidos sean correctos.")
	private String idCliente360;

	@NotBlank(message = "El Firma Digital es requerida para la operación.")
	private String token;

	private String alnova;

	private String pais;

	private String operador;

	private String tokenAccess;

	private String sucursal;

	private String IdSesion;

	private String RemoteAddress;

	public FirmaDigitalEntity() {
		super();
	}

	public FirmaDigitalEntity(String idCliente360, String token) {
		this.idCliente360 = idCliente360;
		this.token = token;

		// Default Data
		this.alnova = "0";
		this.pais = strPais;
		this.operador = strOperador;
		this.tokenAccess = strTokenAcces;
		this.sucursal = strSucursal;
		this.IdSesion = getIdSession().toString();
		this.RemoteAddress = getIpHost();
	}

	private InetAddress localHost = null;

	public String getIpHost() {
		String ipAutorizacion;
		try {
			ipAutorizacion = localHost == null ? UtilsBeans.getLocalIP() : "XXX.XXX.XXX.XXX";
		} catch (UnknownHostException e1) {
			ipAutorizacion = "XXX.XXX.XXX.XXX";
		}
		return ipAutorizacion;
	}

	public Long getIdSession() {

		Timestamp timestamp = new Timestamp(System.currentTimeMillis());
		System.out.println(timestamp);
		return timestamp.getTime();
	}

	public String getIdCliente360() {
		return idCliente360;
	}

	public String getAlnova() {
		return alnova;
	}

	public String getToken() {
		return token;
	}

	public String getPais() {
		return pais;
	}

	public String getOperador() {
		return operador;
	}

	public String getTokenAccess() {
		return tokenAccess;
	}

	public String getSucursal() {
		return sucursal;
	}

	public void setIdCliente360(String idCliente360) {
		this.idCliente360 = idCliente360;
	}

	public void setToken(String token) {
		this.token = token;
	}

	public String getIdSesion() {
		return IdSesion;
	}

	public String getRemoteAddress() {
		return RemoteAddress;
	}

}
