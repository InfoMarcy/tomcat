package com.bancoazteca.ms.firmaDigital.entity;

public class FirmaDigitalConstantes {
	
	public static final String FIRMADIGITAL_PROPERTIES = "firmadigital.properties";
	public static final String FIRMADIGITAL_URL =  "firmadigital.url";
	public static final String FIRMADIGITAL_OPERATOR = "firmadigital.operator";
	public static final String FIRMADIGITAL_PAIS = "firmadigital.pais";
	public static final String FIRMADIGITA_TOKEN_ACCESS =  "firmadigital.token.access";
	public static final String FIRMADIGITA_SUCURSAL = "firmadigital.sucursal";
	public static final String FIRMADIGITAL_IP =  "firmadigital.ip";
	
	
}
