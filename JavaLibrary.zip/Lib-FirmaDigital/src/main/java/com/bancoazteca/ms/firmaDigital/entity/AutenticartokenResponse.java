package com.bancoazteca.ms.firmaDigital.entity;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name = "autenticartoken_response")
public class AutenticartokenResponse  {

	

	private String descriptionCode;
	

	private int statusCode;

	public String getDescriptionCode() {
		return descriptionCode;
	}

	public void setDescriptionCode(String descriptionCode) {
		this.descriptionCode = descriptionCode;
	}

	public int getStatusCode() {
		return statusCode;
	}

	public void setStatusCode(int statusCode) {
		this.statusCode = statusCode;
	}

	@Override
	public String toString() {
		return "AutenticartokenResponse [descriptionCode=" + descriptionCode + ", statusCode=" + statusCode + "]";
	}



	
	
	
	
}


