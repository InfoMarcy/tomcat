package com.bancoazteca.ms.firmaDigital.exceptions;

public class FirmaDigitalException extends Exception {


	private static final long serialVersionUID = 1L;
	
	
	private String mensaje;
	
	public FirmaDigitalException(){ }
	
	public FirmaDigitalException(String message){
		super(message);
		this.mensaje = message;
	}

	public String getMensaje() {
		return mensaje;
	}



}
