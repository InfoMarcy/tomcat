package com.bancoazteca.ms.firmaDigital.entity;


import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.net.InetAddress;
import java.net.NetworkInterface;
import java.net.SocketException;
import java.net.UnknownHostException;
import java.util.List;

/**
 * @author LDC
 *
 */
public class UtilsBeans {

	private UtilsBeans() {

	}
	
	/**
	 * @param method
	 * @param flag
	 */
	public static void enabledAccesToPrivateMethod(Method method, boolean flag) {
		method.setAccessible(flag);
	}
	
	/**
	 * @param field
	 * @param flag
	 */
	public static void enabledAccesToPrivateFields(Field field, boolean flag) {
		field.setAccessible(flag);
	}

	/**
	 * 
	 * @throws UnknownHostException
	 */
	public static final String getLocalIP() throws UnknownHostException {

		return InetAddress.getLocalHost().getHostAddress();
	}

	/**
	 * 
	 * @param ips
	 * @return
	 * @throws UnknownHostException
	 */
	public static final String getLocalIP(List<String> ips) throws UnknownHostException {

		for (String ip : ips) {
			if (ip.equals(getLocalIP())) {
				return ip;
			}
		}

		throw new UnknownHostException();

	}

	/**
	 * 
	 * @param inputFile
	 * @return
	 * @throws FileNotFoundException
	 */
	public static final FileInputStream inputStream(File inputFile) throws FileNotFoundException {
		return new FileInputStream(inputFile);
	}

	/**
	 * 
	 * @param outputFile
	 * @return
	 * @throws FileNotFoundException
	 */
	public static final FileOutputStream outputStream(final File outputFile) throws FileNotFoundException {
		return new FileOutputStream(outputFile);

	}
	
	/**
	 * 
	 * @param path
	 * @return
	 */
	public static final File filePath(final String path){
		return new File(path);

	}

	/**
	 * 
	 * @return
	 * @throws SocketException
	 * @throws UnknownHostException
	 */
	public static final String[] getNetworName() throws SocketException, UnknownHostException {
		String[] macAddres = new String[2];

		NetworkInterface network = NetworkInterface.getByInetAddress(InetAddress.getLocalHost());
		byte[] mac = network.getHardwareAddress();
		StringBuilder sb = new StringBuilder();
		for (int i = 0; i < mac.length; i++) {
			sb.append(String.format("%02X%s", mac[i], (i < mac.length - 1) ? "-" : ""));
		}
		macAddres[0] = sb.toString();
		macAddres[1] = InetAddress.getLocalHost().getHostName();

		return macAddres;
	}
}
