package com.bancoazteca.ms.firmaDigital;

import java.io.StringReader;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import com.bancoazteca.bdm.commons.utils.properties.PropertiesManager;
import com.bancoazteca.ms.firmaDigital.entity.AutenticartokenResponse;
import com.bancoazteca.ms.firmaDigital.entity.FirmaDigitalConstantes;
import com.bancoazteca.ms.firmaDigital.entity.FirmaDigitalEntity;
import com.bancoazteca.ms.firmaDigital.exceptions.FirmaDigitalException;
import com.token.fd.api.command.utils.Crypto;
import com.token.fd.api.utils.exceptions.EncriptaException;

@Component
public class FirmaDigitalComponent extends Crypto {
	
	private static final Logger LOG = LoggerFactory.getLogger(FirmaDigitalComponent.class);

	
	private static final long serialVersionUID = 1L;

	public FirmaDigitalComponent() throws EncriptaException {
		super();
	}
	 
	private static String urlFirmaDigital =PropertiesManager.getInstance().getProperty(FirmaDigitalConstantes.FIRMADIGITAL_PROPERTIES, FirmaDigitalConstantes.FIRMADIGITAL_URL);
	
	private static String ipFirmaDigital =PropertiesManager.getInstance().getProperty(FirmaDigitalConstantes.FIRMADIGITAL_PROPERTIES, FirmaDigitalConstantes.FIRMADIGITAL_IP);

	RestTemplate restTemplate = new RestTemplate();

	
	public Boolean verificarFirmaDigital(String icu, String firmaDigital) throws JAXBException, FirmaDigitalException {
		
		javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(new javax.net.ssl.HostnameVerifier() {

            public boolean verify(String hostname, javax.net.ssl.SSLSession sslSession) {

                return hostname.equals(ipFirmaDigital);

            } 

        });
		
		
		FirmaDigitalEntity entity = new FirmaDigitalEntity(icu, firmaDigital);
		
		//Method which uses JAXB to convert object to XML
		StringBuilder sb = new StringBuilder();
		sb.append("<?xml version=\"1.0\" encoding=\"UTF-8\"?> <autenticartoken_request> <idSesion>");
		sb.append(entity.getIdSesion());
		sb.append("</idSesion> <remoteAddress>");
		sb.append(entity.getRemoteAddress());
		sb.append("</remoteAddress> <alnova>0</alnova> <idCliente360>");
		sb.append(entity.getIdCliente360());
		sb.append("</idCliente360> <operador>");
		sb.append(entity.getOperador());
		sb.append("</operador> <pais>");
		sb.append(entity.getPais());
		sb.append("</pais> <sucursal>");
		sb.append(entity.getSucursal());
		sb.append("</sucursal> <token>");
		sb.append(entity.getToken());
		sb.append("</token> <tokenAccess>");
		sb.append(entity.getTokenAccess());
		sb.append("</tokenAccess> </autenticartoken_request>");

        

		String XMLEncrip = super.encript(sb.toString());

		ResponseEntity<String> response;


		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_FORM_URLENCODED);

		HttpEntity<String> firmaDigitalEntity = new HttpEntity<String>(XMLEncrip, headers);

		response = restTemplate.postForEntity(urlFirmaDigital, firmaDigitalEntity, String.class);

		String XMLDesncrip = super.decript(response.getBody());
		
		
		LOG.info("XMLDesncrip => {}", XMLDesncrip);

		JAXBContext jaxbContext = JAXBContext.newInstance(AutenticartokenResponse.class);
		Unmarshaller unmarshaller = jaxbContext.createUnmarshaller();

		StringReader reader = new StringReader(XMLDesncrip);
		AutenticartokenResponse autenticartokenResponse = (AutenticartokenResponse) unmarshaller.unmarshal(reader);

		
		

		if (autenticartokenResponse.getStatusCode() != 0) {
			
			LOG.info("La firma digital no es valida para la operación.");
			throw new FirmaDigitalException("La firma digital no es valida para la operación.");
		}

		return true;

	}
	
	
	 
}
