import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, FormControl, Validators } from '@angular/forms';
import { AuthenticateServiceService } from '../services/authenticate-service.service';
import { Constants } from '../domain/constants';
import { RestClientService } from '../services/rest-client.service';
import { Router } from '@angular/router';
import { User } from '../domain/user'
import { NotifierService } from 'angular-notifier';
import { OauthService } from '../shared/oauth/oauth.service';
import { HttpHeaders } from '@angular/common/http';

@Component({
  selector: 'app-registro',
  templateUrl: './registro.component.html',
  styleUrls: ['./registro.component.css']
})
export class RegistroComponent implements OnInit {

  registerForm: FormGroup;
  loading = false;
  submitted = false;
  user: User;
  SpinnerVisible : boolean = false;
  oAuthToken;
  constructor
  (
    private formBuilder: FormBuilder,
    private authenticationService: AuthenticateServiceService,
    private restService : RestClientService,
    private router:Router,
    private notifierService: NotifierService,
    private oAuthService: OauthService
  ) 
  {
    
  }

  ngOnInit() 
  {

            // GET OAUTH TOKEN git push origin test
            this.oAuthService.getToken()
            .subscribe(
              res => {
                // console.log(res)
                this.oAuthToken = JSON.stringify(res);
                return;
              },
              err => {
                console.log("Incidencia al conectarse con el servidor OAUTH", err);
              }
            );

    this.registerForm = this.formBuilder.group({
      username: new FormControl('username',[Validators.required, Validators.min(100)]),
      correo: new FormControl('correo',[Validators.required, Validators.maxLength(60), Validators.pattern('^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+.[a-zA-Z0-9-.]+$')])
    });
    this.user = new User();
  }

  
  get username() { return this.registerForm.get('username'); }
  get correo() { return this.registerForm.get('correo'); }


  registrar()
  {
    if(this.registerForm.valid)
    {
      this.SpinnerVisible = true;
      var endpoint = Constants.IP_SERVER_API + Constants.PORT_SERVER_API + Constants.REGISTRO;

      const getToken = JSON.parse(this.oAuthToken);

      let httpOptions = {
         headers: new HttpHeaders({
           'Content-Type':  'application/json',
           'Authorization': this.oAuthService.Encrypt("Bearer " + getToken.access_token)
         })
       };
       
      
      this.restService.post(endpoint, this.user, httpOptions).subscribe((data: {}) => {
         
        if(data)
        {
            var codigoResp = data ? data["codigo"].split(".")[0] : 0
            if(codigoResp == 200)
            {
              this.SpinnerVisible = false;
              this.router.navigate(['usuario-registrado']);
              
            }
            else
            {
              this.notifierService.notify( 'error', 'Error en el servicio de autenticación no respondió correctamente' );
              this.SpinnerVisible = false;
            }
        }
        }, (err) => 
        {
          // this.notifierService.notify( 'error',err.error.mensaje);
          this.SpinnerVisible = false;
        }
      );
    }
    
  }

}
