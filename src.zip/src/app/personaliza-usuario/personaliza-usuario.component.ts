import { Component, OnInit, Input } from "@angular/core";
import { Cliente } from "../domain/cliente";
import { DataClientesService } from "../services/data-clientes.service";
import { FormGroup, FormControl, Validators } from "@angular/forms";
import { NgbDateStruct, NgbCalendar } from "@ng-bootstrap/ng-bootstrap";
import { HttpHeaders } from "@angular/common/http";
import { OauthService } from "../shared/oauth/oauth.service";
import { RestClientService } from "../services/rest-client.service";
import { Constants } from "../domain/constants";

@Component({
  selector: "app-personaliza-usuario",
  templateUrl: "./personaliza-usuario.component.html",
  styleUrls: ["./personaliza-usuario.component.css"]
})
export class PersonalizaUsuarioComponent implements OnInit {
  cliente: Cliente;
  @Input() numeroUsuarios: number;
  clienteGroupValidations: FormGroup;
  model: NgbDateStruct;
  date: { year: number; month: number };
  cte: Cliente;
  private calendar: NgbCalendar;
  maxDate: { year: number; month: number; day: number };
  minDate: { year: number; month: number; day: number };
  entidadesBD;

  validadICU = false;
  validadPass = false;
  validaAlias = false;
  validaAICUReq = false;
  validaNombre = false;
  validaApellidoP = false;
  validaCurp = false;
  validaCurpCorrecta = false;
  validaRfcCorrecta = false;
  validaRfc = false;

  validaEstado = false;
  validaDelegacion = false;
  validaColonia = false;
  validaCodigoP = false;
  validaNumExt = false;
  validaCalle = false;
  validaCelular = false;
  validaCorreo = false;

  validaTipoID = false;
  validaGenero = false;
  validadPassLength = false;
  validaIdIdentificacion = false;
  validaCveEntidadNacimiento = false;
  validaFecha = false;

  validaOCR = false;
  validaNumeroEmision = false;
  validaClaveElector = false;
  validaVigencia = false;
  constructor(
    private dataClienteService: DataClientesService,
    private oAuthService: OauthService,
    private restService: RestClientService
  ) {
    this.cliente = new Cliente();
    let year = new Date().getFullYear();
    let month = new Date().getMonth() + 1;
    let day = new Date().getDate();
    this.maxDate = { year, month, day };
    this.minDate = { year: 1940, month: 1, day: 1 };
    this.initListener2();
    
  }

  initListener2() {
    document.body.addEventListener("keydown", () => this.getFlujos());
    document.body.addEventListener("keyup", () => this.getFlujos());
    document.body.addEventListener("keypress", () => this.getFlujos());
  }

  selectToday() {
    this.model = this.calendar.getToday();
  }

  changeCantidad(cantidad: number, cliente: any) {
    this.cte = JSON.parse(cliente);
    this.removeItem(this.cte);
    this.cte.cantidad = Number(cantidad);
    this.dataClienteService.addElement(this.cte);
    this.listaClientes = this.dataClienteService.getClientes();
  }

  cleanListClient() {
    this.listaClientes = this.dataClienteService.getClientes();
  }

  cleanTableList() {
    this.listaClientes = this.dataClienteService.clean();
  }

  listaClientes = this.dataClienteService.getClientes();

  ngOnInit() {
    this.clienteGroupValidations = new FormGroup({
      ICU: new FormControl("ICU"),
      Alias: new FormControl("Alias"),
      Pass: new FormControl("Pass")
    });

    if (this.getFlujos7()) {
    } else {
      this.clienteGroupValidations = new FormGroup({
        Nombre: new FormControl("Nombre", [Validators.required]),
        ApellidoP: new FormControl("ApellidoP", [Validators.required]),
        ApellidoM: new FormControl("ApellidoM"),
        Genero: new FormControl("Genero", [Validators.required]),
        Telefono: new FormControl("Telefono"),
        Celular: new FormControl("Celular", [Validators.required]),
        Correo: new FormControl("Correo", [
          Validators.required,
          Validators.email
        ]),
        RFC: new FormControl("RFC", []),
        FechaNac: new FormControl("FechaNac", [Validators.required]),
        Curp: new FormControl("Curp", [Validators.required]),
        TipoID: new FormControl("TipoID"),
        OCR: new FormControl("OCR"),
        // CIC: new FormControl("CIC"),
        Calle: new FormControl("Calle", [Validators.required]),
        NumExt: new FormControl("NumExt", [Validators.required]),
        NumInt: new FormControl("NumInt"),
        CodigoP: new FormControl("CodigoP", [Validators.required]),
        Colonia: new FormControl("Colonia", [Validators.required]),
        Delegacion: new FormControl("Delegacion", [Validators.required]),
        Estado: new FormControl("Estado", [Validators.required]),
        CveEntidadNacimiento: new FormControl("CveEntidadNacimiento", [
          Validators.required
        ]),
        ClaveElector: new FormControl("ClaveElector", []),
        AnioRegistro: new FormControl("AnioRegistro"),
        NumeroEmision: new FormControl("NumeroEmision"),
        Vigencia: new FormControl("Vigencia", []),
        ICU: new FormControl("ICU"),
        Alias: new FormControl("Alias"),
        Pass: new FormControl("Pass")
      });
    }

    let httpOptions = {
      headers: new HttpHeaders({
        "Content-Type": "application/json",
        Authorization: this.oAuthService.Encrypt("Bearer ")
      })
    };

    var endpoint =
      Constants.IP_SERVER_API +
      Constants.PORT_SERVER_API +
      Constants.OBTENER_ENTIDADES;

    this.restService.get(endpoint, httpOptions).subscribe(
      res => {
        const respuesta = JSON.stringify(res);
        const entidades = JSON.parse(respuesta);

        this.entidadesBD = entidades.Entidades;
      },
      err => {}
    );


    console.log("dataClienteService On init => ", this.dataClienteService.getClientes().length)
  }

  addCliente() {

    console.log("dataClienteService => ", this.dataClienteService.getClientes().length)
    this.resetvalidations();

    // ====================================== Start flujo 7.1 =======================================//
    // Flujo 7.1
    if (this.getFlujos71() == true) {
      if (this.cliente.icu != undefined && this.cliente.icu.length != 32) {
        if (this.cliente.alias) {
          if (this.cliente.alias.length > 2) {
            delete this.cliente.icu;
          } else {
            this.validadICU = true;
            this.validaAlias = true;
            return;
          }

          if (this.cliente.alias.length < 3 && this.cliente.icu.length == 32) {
            delete this.cliente.alias;
          }
        } else {
          this.validadICU = true;
          this.validaAlias = true;
          return;
        }
      }

      if (this.cliente.alias) {
        if (this.cliente.icu) {
          if (this.cliente.alias.length < 3 && this.cliente.icu.length == 32) {
            delete this.cliente.alias;
          }
        }
      }

      console.log("flujo 7.1");
      this.cliente.cantidad = 1;

      if (this.cliente.icu) {
        this.cliente.icu = this.cliente.icu.toLowerCase();
      }

      this.dataClienteService.addElement(this.cliente);
      console.log("cliente => ", this.cliente);
      this.cliente = new Cliente();
    }

    // ====================================== END flujo 7.1 =======================================//
    // ====================================== Start flujo 7.2 =======================================//
    // Flujo 7.2
    if (this.getFlujos72() == true) {
      if (this.cliente.contra) {
        // passowrd exist valida length
        if (this.cliente.contra.length < 8) {
          this.validadPassLength = true;

          if (!this.cliente.icu) {
            this.validadICU = true;
          }

          if (this.cliente.icu) {
            if (this.cliente.icu.length != 32) {
              this.validadICU = true;
            }
          }

          // valida Alias // validad ICU
          if (!this.cliente.alias) {
            this.validaAlias = true;
          }

          if (this.cliente.alias) {
            if (this.cliente.alias.length < 3) {
              this.validaAlias = true;
            }
          }
          return;
        } else if (this.cliente.contra.length > 7) {
          if (!this.cliente.icu && !this.cliente.alias) {
            this.validaAICUReq = true;
            this.validaAlias = true;
            return;
          }

          if (this.cliente.icu) {
            if (this.cliente.icu.length != 32 && this.cliente.icu.length != 0) {
              if (this.cliente.alias) {
                if (this.cliente.alias.length > 2) {
                  delete this.cliente.icu;
                } else {
                  this.validadICU = true;
                  this.validaAlias = true;
                  return;
                }
              } else {
                this.validadICU = true;
                this.validaAlias = true;
                return;
              }
            }
          }


        } // valida password valid
      }
      // no password provided
      else {
        this.validadPass = true;

        if (this.cliente.icu) {
          if (this.cliente.icu.length != 32) {
            this.validadICU = true;
          }
        } else {
          this.validaAICUReq = true;
        }

        // valida Alias // validad ICU
        if (this.cliente.alias) {
          if (this.cliente.alias.length < 3) {
            this.validaAlias = true;
          }
        } else {
          this.validaAlias = true;
        }
        return;
      }


      if (this.cliente.alias) {
        if (this.cliente.alias.length > 2) {
              delete this.cliente.icu;
        }
      }


      console.log("flujo 7.2");
      this.cliente.cantidad = 1;
      if (this.cliente.icu) {
        this.cliente.icu = this.cliente.icu.toLowerCase();
      }
      this.dataClienteService.addElement(this.cliente);
      console.log("cliente => ", this.cliente);
      this.cliente = new Cliente();
    } // Flujo 7.2

    // ====================================== END flujo 7.2 =======================================//

    if (this.getFlujos7() == false) {
      console.log("Reset the validations flujo false");
      this.resetvalidations();
      // valida Nombre
      if (this.cliente.nombre != undefined && this.cliente.nombre.length < 4) {
        this.validaNombre = true;
      }

      // valida Apellido paterno
      if (
        this.cliente.apellidoP != undefined &&
        this.cliente.apellidoP.length < 4
      ) {
        this.validaApellidoP = true;
      }

      //valida curp
      if (this.cliente.curp != undefined && this.cliente.curp.length != 18) {
        this.validaCurp = true;
      } else if (this.cliente.curp != undefined) {
        this.validarCurp();
      }

      //valida rfc
      if (this.cliente.rfc != undefined && this.cliente.rfc.length != 13) {
        this.validaRfc = true;
      } else if (this.cliente.rfc != undefined) {
        this.validarRFC();
      }

      //valida calle
      if (this.cliente.calle != undefined && this.cliente.calle.length == 0) {
        this.validaCalle = true;
      }

      //valida Numero exterior
      if (this.cliente.numExt != undefined && this.cliente.numExt.length == 0) {
        this.validaNumExt = true;
      }

      //valida Estado
      if (this.cliente.estado != undefined && this.cliente.estado.length == 0) {
        this.validaEstado = true;
      }

      //valida Estado
      if (
        this.cliente.colonia != undefined &&
        this.cliente.colonia.length == 0
      ) {
        this.validaColonia = true;
      }

      //valida Estado
      if (
        this.cliente.delegacion != undefined &&
        this.cliente.delegacion.length == 0
      ) {
        this.validaDelegacion = true;
      }

      //valida codigo postal
      if (this.cliente.cp != undefined && this.cliente.cp.length == 0) {
        this.validaCodigoP = true;
      }

      //valida celular
      if (this.cliente.numCel != undefined && this.cliente.numCel.length == 0) {
        this.validaCelular = true;
      }

      //valida correo
      if (this.cliente.correo != undefined && this.cliente.correo.length == 0) {
        this.validaCorreo = true;
      }

      //valida Tipo Identificación
      if (!this.cliente.idIdentificacion) {
        this.validaIdIdentificacion = true;
      }

      //valida Entidad Nacimiento
      if (
        this.cliente.cveEntidadNacimiento != undefined &&
        this.cliente.cveEntidadNacimiento.length == 0
      ) {
        this.validaCveEntidadNacimiento = true;
      }

      //valida Genero
      if (this.cliente.genero != undefined && this.cliente.genero.length == 0) {
        this.validaGenero = true;
      }

      //valida Fecha Nacimiento
      if (this.model == undefined || this.model == null) {
        this.validaFecha = true;
      }

  
      //valida OCR
      if (this.cliente.ocr != undefined && this.cliente.ocr.length == 0) {
        this.validaOCR = true;
      }

      //valida validaNumeroEmision
      if (
        this.cliente.numeroEmision != undefined &&
        this.cliente.numeroEmision.length == 0
      ) {
        this.validaNumeroEmision = true;
      }

      //valida validaClaveElector
      if (
        this.cliente.claveElector != undefined &&
        this.cliente.claveElector.length == 0
      ) {
        this.validaClaveElector = true;
      }

      //valida validaClaveElector
      if (
        this.cliente.vigencia != undefined &&
        this.cliente.vigencia.length == 0
      ) {
        this.validaVigencia = true;
      }

      // valida Curp y RFC correctas
      if (
        this.validaFecha ||
        this.validaGenero ||
        this.validaCveEntidadNacimiento ||
        this.validaIdIdentificacion ||
        this.validaRfcCorrecta ||
        this.validaCurpCorrecta
      ) {
        return;
      }

      if (this.getFlujos()) {
        if (
          this.validaOCR ||
          this.validaNumeroEmision ||
          this.validaClaveElector ||
          this.validaVigencia
        ) {
          return;
        }
      }

      if (this.clienteGroupValidations.valid) {
        this.cliente.cantidad = Number(this.numeroUsuarios);
        this.cliente.fechaNac = this.getFechaNac();
        this.cliente.idEntidadFederativa = +this.selected;
        this.dataClienteService.addElement(this.cliente);
        this.cliente = new Cliente();
      }
    }
  }

  removeItem(cliente: Cliente) {
    this.dataClienteService.deleteElement(cliente);
  }

  deleteItem(cliente: Cliente) {
    this.dataClienteService.removeElement(cliente);
    this.cleanListClient();
  }

  editItem(cliente: Cliente) {
    console.log("Cliente");
    this.removeItem(cliente);
    this.cleanListClient();
    this.cliente = cliente;
  }

  getFechaNac() {
    var fechastr = "";
    var dia = this.model.day;
    var mes = this.model.month;
    var anio = this.model.year;

    if (dia <= 9) fechastr += "0" + dia;
    else fechastr += "" + dia;

    if (mes <= 9) fechastr += "/0" + mes;
    else fechastr += "/" + mes;

    fechastr += "/" + anio;

    return fechastr;
  }

  get Nombre() {
    return this.clienteGroupValidations.get("Nombre");
  }
  get ApellidoP() {
    return this.clienteGroupValidations.get("ApellidoP");
  }
  get ApellidoM() {
    return this.clienteGroupValidations.get("ApellidoM");
  }
  get Genero() {
    return this.clienteGroupValidations.get("Genero");
  }
  get Telefono() {
    return this.clienteGroupValidations.get("Telefono");
  }
  get Celular() {
    return this.clienteGroupValidations.get("Celular");
  }
  get Correo() {
    return this.clienteGroupValidations.get("Correo");
  }
  get RFC() {
    return this.clienteGroupValidations.get("RFC");
  }
  get FechaNac() {
    return this.clienteGroupValidations.get("FechaNac");
  }
  get Curp() {
    return this.clienteGroupValidations.get("Curp");
  }
  get TipoID() {
    return this.clienteGroupValidations.get("TipoID");
  }
  get OCR() {
    return this.clienteGroupValidations.get("OCR");
  }


  get Calle() {
    return this.clienteGroupValidations.get("Calle");
  }
  get NumExt() {
    return this.clienteGroupValidations.get("NumExt");
  }
  get CodigoP() {
    return this.clienteGroupValidations.get("CodigoP");
  }
  get Colonia() {
    return this.clienteGroupValidations.get("Colonia");
  }
  get Delegacion() {
    return this.clienteGroupValidations.get("Delegacion");
  }
  get Estado() {
    return this.clienteGroupValidations.get("Estado");
  }
  get NumInt() {
    return this.clienteGroupValidations.get("NumInt");
  }
  get CveEntidadNacimiento() {
    return this.clienteGroupValidations.get("CveEntidadNacimiento");
  }
  get ClaveElector() {
    return this.clienteGroupValidations.get("ClaveElector");
  }
  get AnioRegistro() {
    return this.clienteGroupValidations.get("AnioRegistro");
  }
  get NumeroEmision() {
    return this.clienteGroupValidations.get("NumeroEmision");
  }
  get Vigencia() {
    return this.clienteGroupValidations.get("Vigencia");
  }

  get Pass() {
    // if (this.getFlujos72()) {
    return this.clienteGroupValidations.get("Pass");
    // }
  }

  get Alias() {
    // if (this.getFlujos7()) {
    return this.clienteGroupValidations.get("Alias");
    // }
  }

  get ICU() {
    // if (this.getFlujos7()) {
    return this.clienteGroupValidations.get("ICU");
    // }
  }

  selected: number = 0;
  entidadesArray = [];

  selectOption(id: number) {
    this.selected = id;
  }

  getFlujos() {
    let flujoSelected = null;

    flujoSelected = this.oAuthService.getFlujo();
    if (
      flujoSelected == 2.0 ||
      flujoSelected == 2.1 ||
      flujoSelected == 2.2 ||
      flujoSelected == 2.3 ||
      flujoSelected == 2.4
    ) {
      return true;
    } else {
      return false;
    }
  }

  getFlujos7() {
    let flujoSelected = null;
    flujoSelected = this.oAuthService.getFlujo();
    if (flujoSelected == 7.1 || flujoSelected == 7.2) {
      return true;
    } else {
      return false;
    }
  }

  getFlujos72() {
    let flujoSelected = null;
    flujoSelected = this.oAuthService.getFlujo();
    if (flujoSelected == 7.2) {
      return true;
    } else {
      return false;
    }
  }

  getFlujos71() {
    let flujoSelected = null;
    flujoSelected = this.oAuthService.getFlujo();
    if (flujoSelected == 7.1) {
      return true;
    } else {
      return false;
    }
  }

  validarCurp() {
    var expreg = new RegExp(
      /[A-Z][AEIOUX][A-Z]{2}[0-9]{2}(0[1-9]|1[012])(0[1-9]|[12][0-9]|3[01])[MH]([ABCMTZ]S|[BCJMOT]C|[CNPST]L|[GNQ]T|[GQS]R|C[MH]|[MY]N|[DH]G|NE|VZ|DF|SP)[BCDFGHJ-NP-TV-Z]{3}[0-9A-Z][0-9]$/
    );

    console.log("curp => ", this.cliente.curp);
    if (expreg.test(this.cliente.curp)) {
      console.log("La curp es correcta");
      return;
    } else {
      console.log("La curp no es correcta");
      this.validaCurpCorrecta = true;
      return;
    }
  }

  validarRFC() {
    var expreg = new RegExp(
      /[A-Z&amp;Ñ]{3,4}[0-9]{2}(0[1-9]|1[012])(0[1-9]|[12][0-9]|3[01])[A-Z0-9]{2}[0-9A]/
    );
    if (expreg.test(this.cliente.rfc)) {
      console.log("La rfc es correcta");
      return;
    } else {
      console.log("La rfc no es correcta");
      this.validaRfcCorrecta = true;
      return;
    }
  }

  resetvalidations() {
    this.validadICU = false;
    this.validadPass = false;
    this.validaAlias = false;
    this.validaAICUReq = false;
    this.validaNombre = false;
    this.validaApellidoP = false;
    this.validaCurp = false;
    this.validaCurpCorrecta = false;
    this.validaRfcCorrecta = false;
    this.validaRfc = false;
    this.validaEstado = false;
    this.validaDelegacion = false;
    this.validaColonia = false;
    this.validaCodigoP = false;
    this.validaNumExt = false;
    this.validaCalle = false;
    this.validaCelular = false;
    this.validaCorreo = false;
    this.validaTipoID = false;
    this.validaGenero = false;
    this.validadPassLength = false;
    this.validaIdIdentificacion = false;
    this.validaCveEntidadNacimiento = false;
    this.validaFecha = false;

    this.validaOCR = false;
    this.validaNumeroEmision = false;
    this.validaClaveElector = false;
    this.validaVigencia = false;

    return;
  }
}
