import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, of } from 'rxjs';
import { map, tap } from 'rxjs/operators';


@Injectable({
  providedIn: 'root'
})
export class RestClientService {
  constructor(private http: HttpClient) {};

  post(endpoint : string, request: Object, httpOptions) : Observable<Object>
  {
    console.log("Request : "+JSON.stringify(request))

    return this.http.post(endpoint, request, httpOptions).pipe
    (
      tap( (request: Object) => console.log("Post OK") )
    )
  }

  put(endpoint : string, request: Object, httpOptions) : Observable<Object>
  {
    console.log("Request : "+JSON.stringify(request))

    return this.http.put(endpoint, request, httpOptions).pipe
    (
      tap( (request: Object) => console.log("Put OK") )
    )
  }
  

  get(endpoint : string, httpOptions) : Observable<Object>
  {
    return this.http.get(endpoint, httpOptions)
      .pipe(
        map(this.extractData)
      )
  }

  getFront(endpoint : string, httpOptions) : Observable<Object>
  {
    return this.http.get(endpoint, httpOptions)
      .pipe(
        map(this.extractData)
      )
  }

  private extractData(res) {
    let body = res;
    return body || { };
  }

  private handleError<T> (operation = 'operation', result?: T) 
  {
    return (error: any): Observable<T> => 
    {
      console.error(error);
      console.log(`${operation} failed: ${error.message}`);
      return of(result as T);
    };
  }




}
