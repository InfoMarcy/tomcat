import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable } from 'rxjs';
import { User } from '../domain/user'
import { JwtHelperService } from '@auth0/angular-jwt';
import { Router } from '@angular/router';
import * as jwt from 'jsonwebtoken';

@Injectable({
  providedIn: 'root'
})
export class AuthenticateServiceService {


  constructor
  (
    public jwtHelper: JwtHelperService,
    public router: Router
  ) 
  { 
  }

  getUser(key : string)
  {
    return localStorage.getItem(key)
  };

  loginWithNAM(numero_empleado: string, nombre: string)
  {
      localStorage.clear()
      localStorage.setItem('currentUser', numero_empleado);
      localStorage.setItem('nombre', nombre);
      localStorage.setItem('token',this.buildJWT(numero_empleado));
  }

  buildJWT(currentUser : string)
  {
    const token = jwt.sign({ _username: currentUser }, "secret",{ expiresIn: 1200 })
    return token;
  }

  logoutWithNAM()
  {
    localStorage.clear();
    // produccion
    // window.location.assign('https://portal.socio.gs/logout_azteca/cerrar_sesion.html');
    //desarrollo
    window.location.assign('https://authns.desadsi.gs/nidp/app/logout');
  }

  preLogin(token: string) 
  {
      localStorage.clear()
      const decodedToken = this.jwtHelper.decodeToken(token)
      var user = decodedToken["_username"];
      
      return user;
  }

  isAuthenticated() : boolean
  {
    const token = localStorage.getItem("token");
    if(token == null)
      return false;

    return !this.jwtHelper.isTokenExpired(token);
  }

}
