import { Component, OnInit, Pipe, PipeTransform } from '@angular/core';
import { FormGroup} from '@angular/forms';
import { Router} from '@angular/router';
import { Constants } from '../domain/constants'
import { DomSanitizer } from '@angular/platform-browser';
import { AuthenticateServiceService } from '../services/authenticate-service.service'
import { NotifierService } from 'angular-notifier';
import { OauthService } from '../shared/oauth/oauth.service';


@Pipe({ name: 'safe' })
export class SafePipe implements PipeTransform {
  constructor(private sanitizer: DomSanitizer) { }
  transform(url) {
    return this.sanitizer.bypassSecurityTrustResourceUrl(url);
  }
}


@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  loginForm: FormGroup;
  loading = false;
  submitted = false;
  returnUrl: string;
  loginHTML: any;
  loginFormURL : any
  SpinnerVisible : boolean = false;
  numeroEmpleado : string;
  oAuthToken: any;
  validationMessage: boolean = false;

  constructor
  (
    private router:Router,
    private auth: AuthenticateServiceService,
    private notifierService: NotifierService,
    private oAuthService: OauthService
  ) 
  {
     // redirect to home if already logged in
     if (auth.isAuthenticated()) 
     { 
      this.router.navigate(['home']);
     }
  }

  ngOnInit() {

    if (this.GetParam() == null || this.GetParam() == 0) {
      localStorage.clear();
      let endpoint =
        Constants.OBTENER_OAUTH_SERVER +
        Constants.OBTENER_OAUTH_NAM_TOKEN +
        "&" +
        Constants.OBTENER_OAUTH_CLIENTID +
        "&" +
        Constants.OBTENER_OAUTH_CLIENTSECRET +
        "&" +
        Constants.OBTENER_OAUTH_REDIRECTURL_DEV +
        // Constants.OBTENER_OAUTH_REDIRECTURL_PROD +
        "&scope=email&nonce=ab8932b6&state=AB32623HS&acr_values=gs/doblefactoridm/uri";

      // console.log(endpoint)
      window.location.href = endpoint;
    } else {
      this.login();
    }



  };

  GetParam() {
    const results = new RegExp("[\\?&]" + "access_token" + "=([^&#]*)").exec(
      window.location.href
    );
    if (!results) {
      return 0;
    }
    return results[1] || 0;
  };


  login() {
    this.oAuthService.doLogin(this.GetParam()).subscribe(
      res => {
        const respuesta = JSON.stringify(res);
        const loginToken = JSON.parse(respuesta);

        console.log("noEmpleado =>", loginToken.Usuario.nEmpleado);
        console.log("Nombre =>", loginToken.Usuario.nombre);

        this.auth.loginWithNAM(loginToken.Usuario.nEmpleado, loginToken.Usuario.nombre);
        this.router.navigate(['home']);
        this.validationMessage = false;

      },
      err => {
        this.validationMessage = true;
        let that = this;
        if (err.error.Errores.length != null || err.error.Errores.length != undefined) {

          //for loop
          for (let i = 0; i < err.error.Errores.length; i++) {

            if (err.error.Errores[i].registro == false) {
              that.router.navigate(['registro']);
              return;
            } else if (err.error.Errores[i].registro == true && err.error.Errores[i].autorizado == false) {
              that.router.navigate(['unauthorize']);
              return;
            }
          }; // for loop

        };


        if (err.error.bubbles == false) {
          window.location.href = Constants.OBTENER_BACKEND_REDIRECTURL_DEV;
          // window.location.href =  Constants.OBTENER_BACKEND_REDIRECTURL_PROD;

        }
        this.router.navigate(['registro']);
      }
    );


  };

}

