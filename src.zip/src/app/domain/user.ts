export class User 
{
    usuario: string;
    correo: string;
}
