import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-registro-usuario-realizado',
  templateUrl: './registro-usuario-realizado.component.html',
  styleUrls: ['./registro-usuario-realizado.component.css']
})
export class RegistroUsuarioRealizadoComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
