// This file can be replaced during build by using the `fileReplacements` array.
// `ng build --prod` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.

export const environment = {
  production: true,
  auth :
  {
    clientID: "",
    domain : "",
    audience : "",
    redirect : "",
    scope: ""
  },
  loginFormApp:
  {
    cveOauth : "~3$}W>qT8hX),2MV",
    domain : "https://10.51.58.238:3080/banca_digital/v1/login?code=",
    redirect : "&redirectURL=http://10.51.58.237:4200/login?cb"
  }
};
