import { Component, OnInit, Pipe, PipeTransform } from '@angular/core';
import { FormBuilder, FormGroup, Validators , FormControl} from '@angular/forms';
import { Router, ActivatedRoute , Params} from '@angular/router';
import { Constants } from '../domain/constants'
import { from } from 'rxjs';
import { RestClientService } from '../services/rest-client.service';
import * as bootstrap from "bootstrap";
import * as $ from "jquery";
import { environment } from './../../environments/environment';
import { DomSanitizer, SafeResourceUrl, SafeUrl } from '@angular/platform-browser';
import { AuthenticateServiceService } from '../services/authenticate-service.service'
import { NotifierService } from 'angular-notifier';
import { OauthService } from '../shared/oauth/oauth.service';
import { HttpHeaders } from '@angular/common/http';

@Pipe({ name: 'safe' })
export class SafePipe implements PipeTransform {
  constructor(private sanitizer: DomSanitizer) { }
  transform(url) {
    return this.sanitizer.bypassSecurityTrustResourceUrl(url);
  }
}


@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  loginForm: FormGroup;
  loading = false;
  submitted = false;
  returnUrl: string;
  loginHTML: any;
  loginFormURL : any
  SpinnerVisible : boolean = false;
  numeroEmpleado : string;
  oAuthToken: any;
  validationMessage: boolean = false;

  constructor
  (
    private formBuilder: FormBuilder,
    private router:Router,
    private restService : RestClientService,
    private activatedRoute: ActivatedRoute,
    private sanitizer: DomSanitizer,
    private auth: AuthenticateServiceService,
    private notifierService: NotifierService,
    private oAuthService: OauthService

    
  ) 
  {


    //this.loginFormURL = this.doURL()
     // redirect to home if already logged in
     if (auth.isAuthenticated()) 
     { 
      this.router.navigate(['home']);
     }
  }

  ngOnInit() 
  {
    // GET OAUTH TOKEN git push origin test
    // this.oAuthService.getToken()
    //   .subscribe(
    //     res => {
    //       // console.log(res)
    //       this.oAuthToken = JSON.stringify(res);
    //       return;
    //     },
    //     err => {
    //       console.log("Incidencia al conectarse con el servidor OAUTH", err);
    //     }
    //   );



    // this.loginForm = new FormGroup({
    //   numEmpleado : new FormControl('numEmpleado', [ Validators.required ])
    // });


    this.login();
    
  }


  GetParam() {
    const results = new RegExp("[\\?&]" + "access_token" + "=([^&#]*)").exec(
      window.location.href
    );
    if (!results) {
      return 0;
    }
    return results[1] || 0;
  };



  // get numEmpleado() { return this.loginForm.get('numEmpleado'); }


  // goToRegister()
  // {
  //   this.router.navigate(['registro']);
  // }


  // get f() { return this.loginForm.controls; }

  login()
  {
    // const token = JSON.parse(this.oAuthToken);
    // console.log(token.access_token);

    // if(this.loginForm.valid)
    // {

      this.oAuthService.doLogin('364088', this.GetParam()).subscribe(
        res => {
          // console.log(res)
         console.log("res do login => ", res);

          const respuesta = JSON.stringify(res);
          console.log("respuesta =>", respuesta);
          const loginToken = JSON.parse(respuesta);
         
         console.log("loginToken =>", loginToken.Token);
     
        //  token = JSON.parse(this.oAuthToken);
         this.auth.loginWithNAM('364088', loginToken.Token);
        //  $('#closeModal').click();
         this.router.navigate(['home']);
         this.validationMessage = false;

        },
        err => {
              this.validationMessage = true;
          console.log("Incidencia al tratar de hacer login", err);
        }
      );

    
    };
  // }


  /*
  Valida en el WS backend si el usuario ha sido habilitado para acceder al sistema ABC
  */
  validaAccesoLogin(username, token)
  {
      this.SpinnerVisible = true;
      var endpoint = Constants.IP_SERVER_API + Constants.PORT_SERVER_API + Constants.VALIDA_ACCESO_LOGIN;
      var jsonAuth = {"usuario": username};
      const getToken = JSON.parse(this.oAuthToken);

     let httpOptions = {
        headers: new HttpHeaders({
          'Content-Type':  'application/json',
          'Authorization': this.oAuthService.Encrypt("Bearer " + getToken.access_token)
        })
      };
  
      this.restService.post(endpoint, jsonAuth, httpOptions).subscribe((data: {}) => {
         
        if(data)
        {
            var codigoResp = data ? data["codigo"].split(".")[0] : 0
            if(codigoResp == 200)
            {
              this.SpinnerVisible = false;
              this.auth.login(token);
              this.router.navigate(['home']);
            }
            else
            {
              this.notifierService.notify( 'error', data["mensaje"] );
              this.SpinnerVisible = false;
            }
        }
        }, (err) => 
        {
          this.notifierService.notify( 'error',err.error.mensaje);
          this.SpinnerVisible = false;
        }
      );

  }

  onSubmit()
  {
    if (this.loginForm.invalid) 
    {
      return;
    }
    this.loading = true;
    this.router.navigate(['home']);
    //TODO. Autenticacion
  }


  closeModal(token)
  {
    window.top.location.href = window.parent.location+"?token="+token;
    $('#closeModal').click();
    //$('#exampleModal').modal('hide');  
    //window.location.replace("http://192.168.2.4:4200/home");
  };


  // getHeaders() 
  // {
  //   var req = new XMLHttpRequest();
  //   req.open('GET', document.location+"", false);
  //   req.send(null);
    
  //   // associate array to store all values
  //   var data = new Object();
    
  //   // get all headers in one call and parse each item
    
  //   var headers = req.getAllResponseHeaders().toLowerCase();
    
  //   var aHeaders = headers.split('\n');
  //   var i =0;
  //   for (i= 0; i < aHeaders.length; i++) {
  //       var thisItem = aHeaders[i];
  //       var key = thisItem.substring(0, thisItem.indexOf(':'));
  //       var value = thisItem.substring(thisItem.indexOf(':')+1);
  //       data[key] = value;
  //   }	    
    
  //   // get referer
  //   var referer = document.referrer;
  //   data["Referer"] = referer;
    
  //   //get useragent
  //   var useragent = navigator.userAgent;
  //   data["UserAgent"] = useragent;
    
    
  //   //extra code to display the values in html
  //   var display = "";
  //   for(var key in data) {
  //       if (key != ""){
  //         console.log("Key => ", key, ' Value => ', data[key]);
  //       }
  //     // display += "<b>" + key + "</b> : " + data[key] + "<br>";
  //   }

  //   alert("Header contents: "+display);  
  // };

}

