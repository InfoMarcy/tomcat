import { RouterModule, Routes, CanActivate } from '@angular/router';
import { DemoComponent } from './demo/demo.component';
import { ModuleWithProviders } from '@angular/core';
import { LoginComponent } from './login/login.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { AmbientacionComponent } from './ambientacion/ambientacion.component';
import { RegistroComponent } from './registro/registro.component';
import { AuthGuardService } from './services/auth-guard.service';
import { NAMComponent } from './shared/components/nam/nam.component';
import { RedirectComponent } from './shared/components/redirect/redirect.component';

export const router: Routes = [
    //routes for anonimous users

    { path: '', redirectTo: '/nam', pathMatch: 'full' },
    { path: 'home', component: DashboardComponent , canActivate: [AuthGuardService] },
    { path: 'login', component: LoginComponent },
    { path: 'registro', component: RegistroComponent },
    { path: 'ambientacion', component: AmbientacionComponent , canActivate: [AuthGuardService]},
    { path: 'redirect', component: RedirectComponent},
     { path: 'nam', component: NAMComponent }
  
];

export const routes: ModuleWithProviders  = RouterModule.forRoot(router);
// export const routes: ModuleWithProviders  = RouterModule.forRoot(router, {useHash: true});