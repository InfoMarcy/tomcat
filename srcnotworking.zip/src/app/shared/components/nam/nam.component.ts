import { Component, OnInit } from '@angular/core';
import { Constants } from "../../../domain/constants";

@Component({
  selector: 'app-nam',
  templateUrl: './nam.component.html',
  styleUrls: ['./nam.component.css']
})
export class NAMComponent implements OnInit {

  constructor() { }

  ngOnInit() {
    let endpoint =
      Constants.OBTENER_OAUTH_SERVER +
      Constants.OBTENER_OAUTH_NAM_TOKEN +
      "&" +
      Constants.OBTENER_OAUTH_CLIENTID +
      "&" +
      Constants.OBTENER_OAUTH_CLIENTSECRET +
      "&" +
      Constants.OBTENER_OAUTH_REDIRECTURL +
      "&scope=email&nonce=ab8932b6&state=AB32623HS&acr_values=gs/doblefactoridm/uri";

      console.log(endpoint)
     window.location.href = endpoint;
  }

}
