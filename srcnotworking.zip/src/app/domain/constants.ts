export class Constants 
{
    
    public static get IP_SERVER_API() : string { return "https://10.51.58.240:"};
    public static get PORT_SERVER_API() : string { return "443"; };

    //lista de servicios a consumir
    public static get AMBIENTAR_USUARIOS_URL() : string { return "/ambientes/v1/usuarios/"; }
    public static get OBTENER_FLUJOS() : string { return "/ambientes/v1/flujos" }
    public static get OBTENER_CARACTERISTICAS() : string { return "/ambientes/v1/caracteristicas" }
    public static get OBTENER_CLIENTES_AMBIENTADOS_POR_USUARIO() : string { return "/ambientes/v1/consulta/usuario/" }
    public static get OBTENER_FROM_LOGIN() : string { return "https://10.51.58.238:3080/banca_digital/v1/login/" }
    public static get VALIDA_ACCESO_LOGIN() : string { return "/auth/v1/login" }
    public static get OBTENER_OAUTH_TOKEN() : string { return "https://authns.desadsi.gs/nidp/oauth/nam/token?grant_type=password&client_id=780d3cde-a591-42fc-b225-212773a6956b&client_secret=1ymTZkQjBdx9K5lu6tavra_ilM0V4pc6TTiA3-LOy7wDIno5uG4nVaxgJcn46Fpl2UdloDWJippViN9lbgyqQw&username=41900&password=GrupoSalinas2019&acr=secure/name/password/uri" }


    //New Ones
    public static get ELIMINAR_CLIENTE() : string { return "/ambientes/v1/borra/usuario" }
    public static get REGISTRO() : string { return "/auth/v1/registro" }


    public static get OBTENER_OAUTH_SERVER() : string { return "https://authns.desadsi.gs"}
    public static get OBTENER_OAUTH_NAM_TOKEN() : string { return "/nidp/oauth/nam/authz?response_type=token"}
    public static get OBTENER_OAUTH_CLIENTID() : string { return "client_id=863a3522-3aa2-47c1-a4ba-c145ab3e6ead"}
    public static get OBTENER_OAUTH_CLIENTSECRET() : string { return "client_secret=7GjmK6vHq5M153Ug0qe2dqE6xYvne7A8HPKVo6wyqTiapVgYVaxSx5Ct8AgUdyWR7L41WUMZJyt8V3lDRCBXOw"}
    public static get OBTENER_OAUTH_REDIRECTURL() : string { return "redirect_uri=https://10.51.58.238:4080/login"}

}